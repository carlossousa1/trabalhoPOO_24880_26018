﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

using Projeto_POO.Classes;
using Projeto_POO.Classes.Conta;
using Projeto_POO.Classes.Residencia.Pessoa;
using Projeto_POO.Classes.Residencia.Quarto;
using Projeto_POO.Classes.Servico;

namespace Projeto_POO.Funcoes
{
    // Funções básicas, responsáveis pela gestão geral dos dados na lista
    // Seções categorizadas por tipo de dado tratado
    public class GestaoDados
    {
        #region Contas

        public static void ContaListar(List<IConta> listaContas)
        {
            Console.WriteLine("\n Lista Contas:");
            Console.WriteLine("-----------");

            foreach (Conta conta in listaContas)
            {
                Console.WriteLine("ID Conta: {0}", conta.ID_Conta);
                Console.WriteLine("Nome: {0}", conta.nome);
                Console.WriteLine("Data Nascimento: {0}", conta.dataNasc);
                Console.WriteLine("Género: {0}", conta.genero);
                Console.WriteLine("Utilizador: {0}", conta.utilizador);
                Console.WriteLine("Senha: {0}", conta.senha);

                Console.WriteLine("-----------");
                Console.WriteLine("Contactos:");
                foreach (ContaContacto contacontacto in Dados.ListaContaContacto)
                {
                    if (contacontacto.ID_conta == conta.ID_Conta)
                    {
                        foreach (IContacto contacto in Dados.ListaContactos)
                        {
                            if (contacontacto.ID_contacto == contacto.ID_contacto)
                            {
                                Console.WriteLine("{0} ({1})", contacto.valor, contacto.tipo_contacto);
                            }
                        }
                    }
                }
                Console.WriteLine("-----------");
                Console.WriteLine("Moradas:");
                foreach (ContaMorada contamorada in Dados.ListaContaMorada)
                {
                    if (contamorada.ID_conta == conta.ID_Conta)
                    {
                        foreach (IMorada morada in Dados.ListaMoradas)
                        {
                            if (contamorada.ID_morada == morada.ID_morada)
                            {
                                Console.WriteLine("{0} - {1}", morada.morada, morada.cod_postal);
                            }
                        }
                    }
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void ContaAdicionar(List<IConta> listaContas)
        {
            Console.WriteLine("\n Adicionar Conta:");
            Console.WriteLine("-----------");

            // Solicitar ID conta
            int id_conta = -1;
            while (id_conta == -1 || listaContas.Any(r => r.ID_Conta == id_conta))
            {
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            // Solicitar Nome
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            // Solicitar Data de Nascimento
            Console.WriteLine("Data Nascimento (ano, mês, dia): ");
            DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            // Solicitar Género
            string genero = "-1";
            while (genero == "-1" || (genero != "M" && genero != "F"))
            {
                Console.WriteLine("Género (M/F): ");
                genero = Console.ReadLine();
            }

            // Solicitar Nome de Utilizador
            Console.Write("Utilizador: ");
            string utilizador = Console.ReadLine();

            // Solicitar Senha
            Console.Write("Senha: ");
            string senha = Console.ReadLine();

            IConta novaConta = new Conta(id_conta, nome, dataNasc, genero, utilizador, senha);
            listaContas.Add(novaConta);

            Console.WriteLine("-----------\n");
        }

        public static void ContaRemover(List<IConta> listaContas)
        {
            Console.WriteLine("\n Remover Conta:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Conta: ");
            int id_conta = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IConta contaRemover = listaContas.Find(r => r.ID_Conta.Equals(id_conta));

            if (contaRemover != null)
            {
                // Remover grupos com ID relacionado
                Dados.ListaResidentes.RemoveAll(c => c.ID_Conta == contaRemover.ID_Conta);
                Dados.ListaCandidatos.RemoveAll(c => c.ID_Conta == contaRemover.ID_Conta);
                Dados.ListaAdministradores.RemoveAll(c => c.ID_Conta == contaRemover.ID_Conta);
                Dados.ListaFuncionarios.RemoveAll(c => c.ID_Conta == contaRemover.ID_Conta);
                Dados.ListaContaContacto.RemoveAll(c => c.ID_conta == contaRemover.ID_Conta);
                Dados.ListaContaMorada.RemoveAll(c => c.ID_conta == contaRemover.ID_Conta);

                // Remover da lista
                if (contaRemover != null)
                {
                    listaContas.Remove(contaRemover);
                    Console.WriteLine("Conta removida!");
                }
            }

            Console.WriteLine("-----------\n");
        }

        // vincular ID da conta ao contacto escolhido
        public static void ContaVincularContacto(int ID_Conta, int ID_Contacto)
        {
            // verificar se ambos IDs existem
            IConta contaEncontrar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(ID_Conta));

            if (contaEncontrar != null)
            {
                IContacto contactoEncontrar = Dados.ListaContactos.Find(r => r.ID_contacto.Equals(ID_Contacto));
                if (contactoEncontrar != null)
                {
                    ContaContacto novoContacto = new ContaContacto(ID_Conta, ID_Contacto);
                    Dados.ListaContaContacto.Add(novoContacto);
                }
            }
        }

        // desvincular ID da conta ao contacto escolhido
        public static void ContaDesvincularContacto(int ID_Conta, int ID_Contacto)
        {
            // Encontrar o ContaContacto correspondente
            ContaContacto contaContactoRemover = Dados.ListaContaContacto.Find(
                r => r.ID_conta == ID_Conta && r.ID_contacto == ID_Contacto
            );

            // Remover da lista
            if (contaContactoRemover != null)
            {
                Dados.ListaContaContacto.Remove(contaContactoRemover);
            }
        }

        // vincular ID da conta a morada escolhida
        public static void ContaVincularMorada(int ID_Conta, int ID_Morada)
        {
            // verificar se ambos IDs existem
            IConta contaEncontrar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(ID_Conta));
            
            if (contaEncontrar != null)
            {
                IMorada moradaEncontrar = Dados.ListaMoradas.Find(r => r.ID_morada.Equals(ID_Morada));
                if (moradaEncontrar != null)
                {
                    ContaMorada novaMorada = new ContaMorada(ID_Conta, ID_Morada);
                    Dados.ListaContaMorada.Add(novaMorada);
                }
            }
        }

        // desvincular ID da conta a morada escolhida
        public static void ContaDesvincularMorada(int ID_Conta, int ID_Morada)
        {
            // Encontrar o ContaMorada correspondente
            ContaMorada contaMoradaRemover = Dados.ListaContaMorada.Find(
                r => r.ID_conta == ID_Conta && r.ID_morada == ID_Morada
            );

            // Remover da lista
            if (contaMoradaRemover != null)
            {
                Dados.ListaContaMorada.Remove(contaMoradaRemover);
            }
        }

        #endregion

        #region Contactos

        public static void ContactoListar(List<IContacto> listaContactos)
        {
            Console.WriteLine("\n Lista Contactos:");
            Console.WriteLine("-----------");

            foreach (Contacto contacto in listaContactos)
            {
                Console.WriteLine("ID Contacto: {0}", contacto.ID_contacto);
                Console.WriteLine("Valor: {0}", contacto.valor);
                Console.WriteLine("Tipo Contacto: {0}", contacto.tipo_contacto);

                Console.WriteLine("-----------");
                Console.WriteLine("Contas Relacionadas:");
                foreach (ContaContacto contacontacto in Dados.ListaContaContacto)
                {
                    if (contacontacto.ID_contacto == contacto.ID_contacto)
                    {
                        foreach (IConta conta in Dados.ListaContas)
                        {
                            if (contacontacto.ID_conta == conta.ID_Conta)
                            {
                                Console.WriteLine("{0} ({1})", conta.utilizador, conta.ID_Conta);
                            }
                        }
                    }
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void ContactoAdicionar(List<IContacto> listaContactos)
        {
            Console.WriteLine("\n Adicionar Contacto:");
            Console.WriteLine("-----------");

            // Solicitar ID contacto
            int id_contacto = -1;
            while (id_contacto == -1 || listaContactos.Any(r => r.ID_contacto == id_contacto))
            {
                Console.Write("ID Contacto: ");
                id_contacto = int.Parse(Console.ReadLine());
            }

            // Solicitar Tipo
            Console.Write("Tipo: ");
            string tipo = Console.ReadLine();

            // Solicitar Valor
            Console.WriteLine("Valor: ");
            string valor = Console.ReadLine();

            IContacto novoContacto = new Contacto(id_contacto, tipo, valor);
            listaContactos.Add(novoContacto);

            Console.WriteLine("-----------\n");
        }

        public static void ContactoRemover(List<IContacto> listaContactos)
        {
            Console.WriteLine("\n Remover Contacto:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Contacto: ");
            int id_contacto = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IContacto contactoRemover = listaContactos.Find(r => r.ID_contacto.Equals(id_contacto));

            // Remover da lista
            if (contactoRemover != null)
            {
                listaContactos.Remove(contactoRemover);
                Console.WriteLine("Contacto removido!");
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        #region Moradas

        public static void MoradaListar(List<IMorada> listaMoradas)
        {
            Console.WriteLine("\n Lista Moradas:");
            Console.WriteLine("-----------");

            foreach (Morada morada in listaMoradas)
            {
                Console.WriteLine("ID Morada: {0}", morada.ID_morada);
                Console.WriteLine("Morada: {0}", morada.morada);
                Console.WriteLine("Cod. Postal: {0}", morada.cod_postal);

                Console.WriteLine("-----------");
                Console.WriteLine("Contas Relacionadas:");
                foreach (ContaMorada contamorada in Dados.ListaContaMorada)
                {
                    if (contamorada.ID_morada == morada.ID_morada)
                    {
                        foreach (IConta conta in Dados.ListaContas)
                        {
                            if (contamorada.ID_conta == conta.ID_Conta)
                            {
                                Console.WriteLine("{0} ({1})", conta.utilizador, conta.ID_Conta);
                            }
                        }
                    }
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void MoradaAdicionar(List<IMorada> listaMoradas)
        {
            Console.WriteLine("\n Adicionar Morada:");
            Console.WriteLine("-----------");

            // Solicitar ID morada
            int id_morada = -1;
            while (id_morada == -1 || listaMoradas.Any(r => r.ID_morada == id_morada))
            {
                Console.Write("ID Morada: ");
                id_morada = int.Parse(Console.ReadLine());
            }

            // Solicitar Morada
            Console.Write("Morada: ");
            string morada = Console.ReadLine();

            // Solicitar Cod. Postal
            Console.WriteLine("Cod. Postal: ");
            string cod_postal = Console.ReadLine();

            IMorada novaMorada = new Morada(id_morada, morada, cod_postal);
            listaMoradas.Add(novaMorada);

            Console.WriteLine("-----------\n");
        }

        public static void MoradaRemover(List<IMorada> listaMoradas)
        {
            Console.WriteLine("\n Remover Morada:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Morada: ");
            int id_morada = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IMorada moradaRemover = listaMoradas.Find(r => r.ID_morada.Equals(id_morada));

            // Remover da lista
            if (moradaRemover != null)
            {
                listaMoradas.Remove(moradaRemover);
                Console.WriteLine("Morada removida!");
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        #region Residentes

        public static void ResidenteListar(List<IResidente> listaResidentes)
        {
            Console.WriteLine("\n Lista Residentes:");
            Console.WriteLine("-----------");

            foreach (Residente residente in listaResidentes)
            {
                Console.WriteLine("ID Residente: {0}", residente.ID_residente);
                Console.WriteLine("ID Conta: {0}", residente.ID_Conta);
                Console.WriteLine("Dívida: {0}", residente.divida);
                if (residente.ocupando == 0)
                {
                    Console.WriteLine("ID Quarto: (nenhum)");
                }
                else
                {
                    Console.WriteLine("ID Quarto: {0}", residente.ocupando);
                }

                // mais dados relacionados?

                Console.WriteLine("-----------\n");
            }
        }

        public static void ResidenteAdicionar(List<IResidente> listaResidentes)
        {
            Console.WriteLine("\n Adicionar Residente:");
            Console.WriteLine("-----------");

            // Solicitar ID residente
            int id_residente = -1;
            while (id_residente == -1 || listaResidentes.Any(r => r.ID_residente == id_residente))
            {
                Console.Write("ID Residente: ");
                id_residente = int.Parse(Console.ReadLine());
            }

            // Solicitar ID conta
            int id_conta = -1;
            IConta contaachar;
            while ((contaachar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(id_conta))) == null || Dados.ListaResidentes.Find(r => r.ID_Conta.Equals(id_conta)) != null)
            {
                
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            IResidente novoResidente = new Residente(id_residente, 0, 0, id_conta, "", DateOnly.FromDateTime(DateTime.Today), "", "", "");
            listaResidentes.Add(novoResidente);

            Console.WriteLine("-----------\n");
        }

        public static void ResidenteRemover(List<IResidente> listaResidentes)
        {
            Console.WriteLine("\n Remover Residente:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Residente: ");
            int id_residente = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IResidente residenteRemover = listaResidentes.Find(r => r.ID_residente.Equals(id_residente));

            if (residenteRemover != null)
            {
                // Remover grupos com ID relacionado
                Dados.ListaQuartoResidente.RemoveAll(c => c.ID_residente == residenteRemover.ID_residente);

                // Remover da lista
                if (residenteRemover != null)
                {
                    listaResidentes.Remove(residenteRemover);
                    Console.WriteLine("Residente removido!");
                }
            }

            Console.WriteLine("-----------\n");
        }

        // atualizar status "ocupando" do residente escolhido
        public static void ResidenteOcupando(List<IResidente> listaResidentes, int ID_residente)
        {
            int count = 0;
            foreach (IResidente residente in listaResidentes)
            {
                if(ID_residente == residente.ID_residente)
                {
                    foreach (QuartoResidente quartoresidente in Dados.ListaQuartoResidente)
                    {
                        if (quartoresidente.ID_residente == ID_residente)
                        {
                            count = count + 1;
                        }
                    }
                    if (count == 0)
                    {
                        // nao ocupa nenhum quarto
                        residente.ocupando = 0;
                    }
                    else
                    {
                        // esta ocupando um quarto
                        residente.ocupando = 1;
                    }
                }
            }
        }

        // vincular ID do residente ao quarto escolhido
        public static void ResidenteOcupar(int ID_residente, int ID_quarto)
        {
            // verificar se ambos IDs existem
            IResidente residenteEncontrar = Dados.ListaResidentes.Find(r => r.ID_residente.Equals(ID_residente));
            // Remover da lista
            if (residenteEncontrar != null)
            {
                IQuarto quartoEncontrar = Dados.ListaQuartos.Find(r => r.ID_quarto.Equals(ID_quarto));
                if (quartoEncontrar != null)
                {
                    if (QuartoLotacao(Dados.ListaQuartos, ID_quarto) == quartoEncontrar.lotacao)
                    {
                        Console.WriteLine("Lotação Excedida!");
                    }
                    else
                    {
                        QuartoResidente novoResidente = new QuartoResidente(ID_quarto, ID_residente);
                        Dados.ListaQuartoResidente.Add(novoResidente);
                    }
                }
            }
        }

        // desvincular ID do residente ao quarto escolhido
        public static void ResidenteDesocupar(int ID_residente, int ID_quarto)
        {
            // Encontrar o QuartoResidente correspondente
            QuartoResidente quartoResidenteRemover = Dados.ListaQuartoResidente.Find(
                r => r.ID_residente == ID_residente && r.ID_quarto == ID_quarto
            );

            // Remover da lista
            if (quartoResidenteRemover != null)
            {
                Dados.ListaQuartoResidente.Remove(quartoResidenteRemover);
            }
        }

        #endregion

        #region Candidatos

        public static void CandidatoListar(List<ICandidato> listaCandidatos)
        {
            Console.WriteLine("\n Lista Candidatos:");
            Console.WriteLine("-----------");

            foreach (Candidato candidato in listaCandidatos)
            {
                Console.WriteLine("ID Candidato: {0}", candidato.ID_cantidato);
                Console.WriteLine("ID Conta: {0}", candidato.ID_Conta);
                if (candidato.estado == 0)
                {
                    Console.WriteLine("Estado: Inativo");
                }
                else
                {
                    Console.WriteLine("Estado: Ativo");
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void CandidatoAdicionar(List<ICandidato> listaCandidatos)
        {
            Console.WriteLine("\n Adicionar Candidato:");
            Console.WriteLine("-----------");

            // Solicitar ID candidato
            int id_candidato = -1;
            while (id_candidato == -1 || listaCandidatos.Any(r => r.ID_cantidato == id_candidato))
            {
                Console.Write("ID Candidato: ");
                id_candidato = int.Parse(Console.ReadLine());
            }

            // Solicitar ID conta
            int id_conta = -1;
            IConta contaachar;
            while ((contaachar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(id_conta))) == null || Dados.ListaCandidatos.Find(r => r.ID_Conta.Equals(id_conta)) != null)
            {
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            // Solicitar Estado
            /*int estado = -1;
            while (estado == -1 && (estado != 0 || estado != 1))
            {
                Console.WriteLine("Estado (0/1): ");
                estado = int.Parse(Console.ReadLine());
            }*/

            ICandidato novoCandidato = new Candidato(id_candidato, 0, id_conta, "", DateOnly.FromDateTime(DateTime.Today), "", "", "");
            listaCandidatos.Add(novoCandidato);

            Console.WriteLine("-----------\n");
        }

        public static void CandidatoRemover(List<ICandidato> listaCandidatos)
        {
            Console.WriteLine("\n Remover Candidato:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Candidato: ");
            int id_candidato = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            ICandidato candidatoRemover = listaCandidatos.Find(r => r.ID_cantidato.Equals(id_candidato));

            if (candidatoRemover != null)
            {
                // Remover candidaturas com ID relacionado
                Dados.ListaCandidatura.RemoveAll(c => c.ID_candidato == candidatoRemover.ID_cantidato);

                // Remover da lista
                if (candidatoRemover != null)
                {
                    listaCandidatos.Remove(candidatoRemover);
                    Console.WriteLine("Candidato removido!");
                }
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        #region Candidaturas
        public static void CandidaturaListar(List<Candidatura> listaCandidatura)
        {
            Console.WriteLine("\n Lista Candidaturas:");
            Console.WriteLine("-----------");

            foreach (Candidatura candidatura in listaCandidatura)
            {
                Console.WriteLine("ID Candidatura: {0}", candidatura.ID_candidatura);
                foreach (ICandidato candidato in Dados.ListaCandidatos)
                {
                    if (candidato.ID_cantidato == candidatura.ID_candidato)
                    {
                        Console.WriteLine("ID Candidato: {0}", candidato.ID_cantidato);
                    }
                }
                Console.WriteLine("Data Candidatura: {0}", candidatura.dataCandidatura);

                Console.WriteLine("-----------\n");
            }
        }

        public static void CandidaturaAdicionar(List<Candidatura> listaCandidatura)
        {
            Console.WriteLine("\n Adicionar Candidatura:");
            Console.WriteLine("-----------");

            // Solicitar ID candidatura
            int id_candidatura = -1;
            while (id_candidatura == -1 || listaCandidatura.Any(r => r.ID_candidatura == id_candidatura))
            {
                Console.Write("ID Candidatura: ");
                id_candidatura = int.Parse(Console.ReadLine());
            }

            // Solicitar ID candidato
            int id_candidato = -1;
            ICandidato candidatoachar;
            while ((candidatoachar = Dados.ListaCandidatos.Find(r => r.ID_cantidato.Equals(id_candidato))) == null)
            {
                Console.Write("ID Candidto: ");
                id_candidato = int.Parse(Console.ReadLine());
            }

            // Solicitar Data de Nascimento
            Console.WriteLine("Data (ano, mês, dia): ");
            DateOnly data = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            Candidatura novaCandidatura = new Candidatura(id_candidatura, id_candidato, data);
            listaCandidatura.Add(novaCandidatura);
            Solicitacao novaProposta = new Solicitacao(id_candidatura+1000, 2, new DateOnly(1,1,1), candidatoachar.ID_Conta, "Candidatura: "+candidatoachar.ID_Conta, 0, "");
            Dados.ListaSolicitacoes.Add(novaProposta);

            Console.WriteLine("-----------\n");
        }

        public static void CandidaturaRemover(List<Candidatura> listaCandidatura)
        {
            Console.WriteLine("\n Remover Candidatura:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Candidatura: ");
            int id_candidatura = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            Candidatura candidaturaRemover = listaCandidatura.Find(r => r.ID_candidatura.Equals(id_candidatura));

            // Remover da lista
            if (candidaturaRemover != null)
            {
                listaCandidatura.Remove(candidaturaRemover);
                Console.WriteLine("Candidatura removida!");
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        #region Administradores

        public static void AdministradorListar(List<IAdministrador> listaAdministradores)
        {
            Console.WriteLine("\n Lista Administradores:");
            Console.WriteLine("-----------");

            foreach (IAdministrador administrador in listaAdministradores)
            {
                Console.WriteLine("ID Administrador: {0}", administrador.ID_admin);
                Console.WriteLine("ID Conta: {0}", administrador.ID_Conta);

                Console.WriteLine("-----------\n");
            }
        }

        public static void AdministradorAdicionar(List<IAdministrador> listaAdministradores)
        {
            Console.WriteLine("\n Adicionar Administrador:");
            Console.WriteLine("-----------");

            // Solicitar ID administrador
            int id_administrador = -1;
            while (id_administrador == -1 || listaAdministradores.Any(r => r.ID_admin == id_administrador))
            {
                Console.Write("ID Administrador: ");
                id_administrador = int.Parse(Console.ReadLine());
            }

            // Solicitar ID conta
            int id_conta = -1;
            IConta contaachar;
            while ((contaachar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(id_conta))) == null || Dados.ListaAdministradores.Find(r => r.ID_Conta.Equals(id_conta)) != null)
            {
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            IAdministrador novoAdministrador = new Administrador(id_administrador, id_conta, "", DateOnly.FromDateTime(DateTime.Today), "", "", "");
            listaAdministradores.Add(novoAdministrador);

            Console.WriteLine("-----------\n");
        }

        public static void AdministradorRemover(List<IAdministrador> listaAdministradores)
        {
            Console.WriteLine("\n Remover Administrador:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Administrador: ");
            int id_administrador = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IAdministrador administradorRemover = listaAdministradores.Find(r => r.ID_admin.Equals(id_administrador));

            // Remover da lista
            if (administradorRemover != null)
            {
                listaAdministradores.Remove(administradorRemover);
                Console.WriteLine("Administrador removido!");
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        #region Funcionarios
        public static void FuncionarioListar(List<IFuncionario> listaFuncionarios)
        {
            Console.WriteLine("\n Lista Funcionarios:");
            Console.WriteLine("-----------");

            foreach (IFuncionario funcionario in listaFuncionarios)
            {
                Console.WriteLine("ID Funcionario: {0}", funcionario.ID_funcionario);
                Console.WriteLine("ID Conta: {0}", funcionario.ID_Conta);
                Console.WriteLine("Tipo de Serviço: {0}", funcionario.tipoServ);

                Console.WriteLine("-----------\n");
            }
        }

        public static void FuncionarioAdicionar(List<IFuncionario> listaFuncionarios)
        {
            Console.WriteLine("\n Adicionar Funcionario:");
            Console.WriteLine("-----------");

            // Solicitar ID funcionario
            int id_funcionario = -1;
            while (id_funcionario == -1 || listaFuncionarios.Any(r => r.ID_funcionario == id_funcionario))
            {
                Console.Write("ID Funcionário: ");
                id_funcionario = int.Parse(Console.ReadLine());
            }

            // Solicitar ID conta
            int id_conta = -1;
            IConta contaachar;
            while ((contaachar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(id_conta))) == null || Dados.ListaFuncionarios.Find(r => r.ID_Conta.Equals(id_conta)) != null)
            {
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            // Definir tipo de serviço
            int tipoServ = -1;
            while (tipoServ == -1 || (tipoServ != 1 && tipoServ != 2))
            {
                Console.WriteLine("Tipo Serviço (1-Limpeza, 2-Manutenção): ");
                tipoServ = int.Parse(Console.ReadLine());
            }

            IFuncionario novoFuncionario = new Funcionario(id_funcionario, tipoServ, id_conta, "", DateOnly.FromDateTime(DateTime.Today), "", "", "");
            listaFuncionarios.Add(novoFuncionario);

            Console.WriteLine("-----------\n");
        }

        public static void FuncionarioRemover(List<IFuncionario> listaFuncionarios)
        {
            Console.WriteLine("\n Remover Funcionario:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Funcionario: ");
            int id_funcionario = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IFuncionario funcionarioRemover = listaFuncionarios.Find(r => r.ID_funcionario.Equals(id_funcionario));

            // Remover da lista
            if (funcionarioRemover != null)
            {
                listaFuncionarios.Remove(funcionarioRemover);
                Console.WriteLine("Funcionario removido!");
            }

            Console.WriteLine("-----------\n");
        }
        #endregion

        #region Quartos
        // conta o numero de residentes em um quarto
        public static int QuartoLotacao(List<IQuarto> listaQuartos, int ID_quarto)
        {
            int lotacao = 0;
            
            foreach (IQuarto quarto in listaQuartos)
            {
                if (ID_quarto == quarto.ID_quarto)
                {
                    foreach (QuartoResidente quartoresidente in Dados.ListaQuartoResidente)
                    {
                        if (quartoresidente.ID_quarto == ID_quarto)
                        {
                            lotacao = lotacao + 1;
                        }
                    }
                }
            }

            return lotacao;
        }

        public static void QuartoListar(List<IQuarto> listaQuartos)
        {
            Console.WriteLine("\n Lista Quartos:");
            Console.WriteLine("-----------");

            foreach (IQuarto quarto in listaQuartos)
            {
                Console.WriteLine("ID Quarto: {0}", quarto.ID_quarto);
                Console.WriteLine("Tipo Quarto: T{0}", quarto.tipoQuarto);
                Console.WriteLine("Lotacao: {0}/{1}", QuartoLotacao(listaQuartos, quarto.ID_quarto), quarto.lotacao);

                Console.WriteLine("-----------");
                Console.WriteLine("Residentes:");
                foreach (QuartoResidente quartoresidente in Dados.ListaQuartoResidente)
                {
                    if (quartoresidente.ID_quarto == quarto.ID_quarto)
                    {
                        foreach (IResidente residente in Dados.ListaResidentes)
                        {
                            if (residente.ID_residente == quartoresidente.ID_residente)
                            {
                                foreach (IConta conta in Dados.ListaContas)
                                {
                                    if (conta.ID_Conta == residente.ID_Conta)
                                    {
                                        Console.WriteLine("{0} ({1})", conta.nome, residente.ID_residente);
                                    }
                                }
                            }
                        }
                    }
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void QuartoAdicionar(List<IQuarto> listaQuartos)
        {
            Console.WriteLine("\n Adicionar Quarto:");
            Console.WriteLine("-----------");

            // Solicitar ID quarto
            int id_quarto = -1;
            while (id_quarto == -1 || listaQuartos.Any(r => r.ID_quarto == id_quarto))
            {
                Console.Write("ID Quarto: ");
                id_quarto = int.Parse(Console.ReadLine());
            }

            // Definir tipo
            Console.WriteLine("Tipo: ");
            int tipo = int.Parse(Console.ReadLine());

            // Definir lotacao
            Console.WriteLine("Lotacao: ");
            int lotacao = int.Parse(Console.ReadLine());

            IQuarto novoQuarto = new Quarto(id_quarto, tipo, lotacao);
            listaQuartos.Add(novoQuarto);

            Console.WriteLine("-----------\n");
        }

        public static void QuartoRemover(List<IQuarto> listaQuartos)
        {
            Console.WriteLine("\n Remover Quarto:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Quarto: ");
            int id_quarto = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            IQuarto quartoRemover = listaQuartos.Find(r => r.ID_quarto.Equals(id_quarto));

            if (quartoRemover != null)
            {
                // Remover alocações com ID relacionado
                Dados.ListaQuartoResidente.RemoveAll(c => c.ID_quarto == quartoRemover.ID_quarto);
                // Atualizar status "ocupando" de cada cliente
                foreach (IResidente residente in Dados.ListaResidentes)
                {
                    foreach (QuartoResidente quartoresidente in Dados.ListaQuartoResidente)
                    {
                        if (quartoresidente.ID_residente == residente.ID_residente && quartoresidente.ID_quarto == quartoRemover.ID_quarto)
                        {
                            ResidenteOcupando(Dados.ListaResidentes, residente.ID_residente);
                        }
                    }
                }

                // Remover da lista
                if (quartoRemover != null)
                {
                    listaQuartos.Remove(quartoRemover);
                    Console.WriteLine("Quarto removido!");
                }
            }

            Console.WriteLine("-----------\n");
        }
        #endregion

        #region Proposta
        public static void PropostaListar(List<Solicitacao> listaSolicitacoes)
        {
            Console.WriteLine("\n Lista Propostas:");
            Console.WriteLine("-----------");

            foreach (Solicitacao solicitacao in listaSolicitacoes)
            {
                Console.WriteLine("ID Proposta: {0}", solicitacao.ID_solicitacao);
                switch (solicitacao.tipoSolicitacao)
                {
                    // Realocar Quarto
                    case 1:
                        Console.WriteLine("Tipo: Realocação Quarto ({0})", solicitacao.tipoSolicitacao);
                        break;
                    // Trocar Quarto
                    case 2:
                        Console.WriteLine("Tipo: Candidatura ({0})", solicitacao.tipoSolicitacao);
                        break;
                    // Requerir Limpeza
                    case 3:
                        Console.WriteLine("Tipo: Requisição Limpeza ({0})", solicitacao.tipoSolicitacao);
                        break;
                    // Requerir Manutenção
                    case 4:
                        Console.WriteLine("Tipo: Requisição Manutenção ({0})", solicitacao.tipoSolicitacao);
                        break;
                }
                Console.WriteLine("Data: {0}", solicitacao.dataSolicitacao);
                Console.WriteLine("ID Conta: {0}", solicitacao.ID_Conta);
                if (solicitacao.status == 0)
                {
                    Console.WriteLine("Status: Por Responder");
                    Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                }
                else if (solicitacao.status == 1)
                {
                    if (solicitacao.tipoSolicitacao >= 1 && solicitacao.tipoSolicitacao <= 2)
                    {
                        Console.WriteLine("Status: Aceito");
                    }
                    if (solicitacao.tipoSolicitacao >= 3 && solicitacao.tipoSolicitacao <= 4)
                    {
                        Console.WriteLine("Status: Concluído");
                    }
                    Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                    Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                }
                else if (solicitacao.status == 2)
                {
                    Console.WriteLine("Status: Rejeitado");
                    Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                    Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                }

                Console.WriteLine("-----------\n");
            }
        }

        public static void PropostaAdicionar(List<Solicitacao> listaSolicitacoes)
        {
            Console.WriteLine("\n Adicionar Proposta:");
            Console.WriteLine("-----------");

            // Solicitar ID proposta
            int id_proposta = -1;
            while (id_proposta == -1 || listaSolicitacoes.Any(r => r.ID_solicitacao == id_proposta))
            {
                Console.Write("ID Proposta: ");
                id_proposta = int.Parse(Console.ReadLine());
            }

            // Solicitar ID conta
            int id_conta = -1;
            IConta contaachar;
            while ((contaachar = Dados.ListaContas.Find(r => r.ID_Conta.Equals(id_conta))) == null)
            {
                Console.Write("ID Conta: ");
                id_conta = int.Parse(Console.ReadLine());
            }

            // Definir tipo de proposta
            int tipoSolicitacao = -1;
            while (tipoSolicitacao == -1 || (tipoSolicitacao != 1 && tipoSolicitacao != 2 && tipoSolicitacao != 3 && tipoSolicitacao != 4))
            {
                Console.WriteLine("Tipo Solicitação (1-Realocação, 3-Limpeza, 4-Manutenção): ");
                tipoSolicitacao = int.Parse(Console.ReadLine());
            }

            // Solicitar Data de Nascimento
            Console.WriteLine("Data (ano, mês, dia): ");
            DateOnly data = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            // Definir tipo
            Console.WriteLine("Justificação: \n");
            string justificacao = Console.ReadLine();

            Solicitacao novaSolicitacao = new Solicitacao(id_proposta, tipoSolicitacao, data, id_conta, justificacao, 0, "");
            listaSolicitacoes.Add(novaSolicitacao);

            Console.WriteLine("-----------\n");
        }

        public static void PropostaRemover(List<Solicitacao> listaSolicitacoes)
        {
            Console.WriteLine("\n Remover Solicitacao:");
            Console.WriteLine("-----------");

            // Solicitar ID a ser removido
            Console.Write("ID Solicitacao: ");
            int id_solicitacao = int.Parse(Console.ReadLine());

            // Procurar ID na lista
            Solicitacao solicitacaoRemover = listaSolicitacoes.Find(r => r.ID_solicitacao.Equals(id_solicitacao));

            // Remover da lista
            if (solicitacaoRemover != null)
            {
                listaSolicitacoes.Remove(solicitacaoRemover);
                Console.WriteLine("Solicitacao removida!");
            }

            Console.WriteLine("-----------\n");
        }

        #endregion

        // ---- outras funcionalidades
        public static void PerfilListar()
        {
            Console.WriteLine("\n Perfil:");
            Console.WriteLine("-----------");

            foreach (Conta conta in Dados.ListaContas)
            {
                if (conta.ID_Conta == SistemaLogin.ID_logado)
                {
                    Console.WriteLine("ID Conta: {0}", conta.ID_Conta);
                    Console.WriteLine("Nome: {0}", conta.nome);
                    Console.WriteLine("Data Nascimento: {0}", conta.dataNasc);
                    Console.WriteLine("Género: {0}", conta.genero);
                    Console.WriteLine("Utilizador: {0}", conta.utilizador);
                    Console.WriteLine("Senha: {0}", conta.senha);

                    Console.WriteLine("-----------");
                    Console.WriteLine("Contactos:");
                    foreach (ContaContacto contacontacto in Dados.ListaContaContacto)
                    {
                        if (contacontacto.ID_conta == conta.ID_Conta)
                        {
                            foreach (IContacto contacto in Dados.ListaContactos)
                            {
                                if (contacontacto.ID_contacto == contacto.ID_contacto)
                                {
                                    Console.WriteLine("{0} ({1})", contacto.valor, contacto.tipo_contacto);
                                }
                            }
                        }
                    }
                    Console.WriteLine("-----------");
                    Console.WriteLine("Moradas:");
                    foreach (ContaMorada contamorada in Dados.ListaContaMorada)
                    {
                        if (contamorada.ID_conta == conta.ID_Conta)
                        {
                            foreach (IMorada morada in Dados.ListaMoradas)
                            {
                                if (contamorada.ID_morada == morada.ID_morada)
                                {
                                    Console.WriteLine("{0} - {1}", morada.morada, morada.cod_postal);
                                }
                            }
                        }
                    }
                    Console.WriteLine("-----------");
                    if (SistemaLogin.Modo == 1)
                    {
                        Console.WriteLine("Modo: Administrador");
                    }
                    if (SistemaLogin.Modo == 2)
                    {
                        Console.WriteLine("Modo: Residente");
                        Console.Write("Quartos: ");
                        foreach (Residente residente in Dados.ListaResidentes)
                        {
                            if (residente.ID_Conta == conta.ID_Conta)
                            {
                                foreach (QuartoResidente quarto in Dados.ListaQuartoResidente)
                                {
                                    if (quarto.ID_residente == residente.ID_residente)
                                    {
                                        Console.Write("{0} ", quarto.ID_quarto);
                                    }
                                }
                            }
                        }
                    }
                    if (SistemaLogin.Modo == 3)
                    {
                        Console.WriteLine("Modo: Candidato");
                    }
                    if (SistemaLogin.Modo == 4)
                    {
                        Console.WriteLine("Modo: Funcionário");
                        foreach (Funcionario funcionario in Dados.ListaFuncionarios)
                        {
                            if (funcionario.ID_Conta == conta.ID_Conta)
                            {
                                if(funcionario.tipoServ == 1)
                                {
                                    Console.WriteLine("Equipe: Limpeza");
                                }
                                if (funcionario.tipoServ == 2)
                                {
                                    Console.WriteLine("Equipe: Manutenção");
                                }
                            }
                        }
                    }
                }

                Console.WriteLine("\n-----------\n");
            }
        }

        public static void PropostaAtualizar()
        {
            Console.WriteLine("\n-----------");
            Console.WriteLine("Atualizar Solicitação:");

            // Solicitar ao usuário o ID da solicitacao a ser atualizada
            Console.Write("ID da Solicitação a ser atualizada: ");
            int ID_Solicitacao_Find = int.Parse(Console.ReadLine());

            // Procurar solicitação na lista pelo id
            Solicitacao solicitacaoParaEditar = Dados.ListaSolicitacoes.Find(r => r.ID_solicitacao.Equals(ID_Solicitacao_Find));

            if (solicitacaoParaEditar != null)
            {
                if (solicitacaoParaEditar.status == 0)
                {
                    Console.WriteLine("-----------");
                    solicitacaoParaEditar.status = 1;
                    Console.WriteLine("-----------\n");

                    string resposta = "-1";
                    while (resposta == "-1" || (resposta != "S" && resposta != "N"))
                    {
                        Console.Write("Validar Solicitação? (S/N): ");
                        resposta = Console.ReadLine();
                    }

                    Console.WriteLine("Resposta:");
                    string retorno = Console.ReadLine();
                    solicitacaoParaEditar.resposta = retorno;

                    // Validou
                    if (resposta == "S")
                    {
                        // atualizar status
                        solicitacaoParaEditar.status = 1;

                        // Efetuar Pedido
                        switch (solicitacaoParaEditar.tipoSolicitacao)
                        {
                            case 1: // realocação quarto

                                IResidente residenteParaEditar = Dados.ListaResidentes.Find(r => r.ID_Conta.Equals(solicitacaoParaEditar.ID_Conta));
                                if (residenteParaEditar != null)
                                {
                                    Console.Write("ID Quarto: ");
                                    int novo_quarto;
                                    novo_quarto = int.Parse(Console.ReadLine());

                                    IQuarto quartoEncontrar = Dados.ListaQuartos.Find(r => r.ID_quarto.Equals(novo_quarto));

                                    if (quartoEncontrar != null)
                                    {
                                        if (QuartoLotacao(Dados.ListaQuartos, novo_quarto) >= quartoEncontrar.lotacao)
                                        {
                                            Console.WriteLine("Ocupação Excedida!");
                                            solicitacaoParaEditar.status = 2;
                                        }
                                        else
                                        {
                                            // Relocar Residente

                                            resposta = "-1";
                                            while (resposta == "-1" || (resposta != "S" && resposta != "N"))
                                            {
                                                Console.Write("Remover Ocupações Anteriores? (S/N): ");
                                                resposta = Console.ReadLine();
                                            }
                                            // Remover quarto anteriormente ocupado
                                            if (resposta == "S")
                                            {
                                                // Crie uma cópia da lista para evitar a exceção de modificação durante a iteração
                                                var listaQuartoResidenteCopy = new List<QuartoResidente>(Dados.ListaQuartoResidente);

                                                foreach (QuartoResidente quartoresidente in listaQuartoResidenteCopy)
                                                {
                                                    if (quartoresidente.ID_residente == residenteParaEditar.ID_residente)
                                                    {
                                                        ResidenteDesocupar(residenteParaEditar.ID_residente, quartoresidente.ID_quarto);
                                                    }
                                                }
                                            }

                                            // Alocar ao novo quarto
                                            ResidenteOcupar(residenteParaEditar.ID_residente, novo_quarto);
                                            // atualizar status "ocupando" do residente escolhido
                                            ResidenteOcupando(Dados.ListaResidentes, residenteParaEditar.ID_residente);

                                            // Atualizar status
                                            solicitacaoParaEditar.status = 1;
                                        }
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Quarto não existe!");
                                    solicitacaoParaEditar.status = 0;
                                }
                                break;

                            case 2: // candidatura
                                ICandidato candidatoParaEditar = Dados.ListaCandidatos.Find(r => r.ID_Conta.Equals(solicitacaoParaEditar.ID_Conta));

                                if (candidatoParaEditar != null)
                                {
                                    // Crie uma cópia da ListaCandidatura para evitar a exceção de modificação durante a iteração
                                    var listaCandidaturaCopy = new List<Candidatura>(Dados.ListaCandidatura);

                                    foreach (Candidatura candidatura in listaCandidaturaCopy)
                                    {
                                        if (candidatura.ID_candidato == candidatoParaEditar.ID_cantidato)
                                        {
                                            Dados.ListaCandidatura.Remove(candidatura);
                                        }
                                    }

                                    // Adicionar novo residente
                                    // Solicitar ID residente
                                    int id_residente = -1;
                                    while (id_residente == -1 || Dados.ListaResidentes.Any(r => r.ID_residente == id_residente))
                                    {
                                        Console.Write("ID Residente: ");
                                        id_residente = int.Parse(Console.ReadLine());
                                    }

                                    IResidente novoResidente = new Residente(id_residente, 0, 0, candidatoParaEditar.ID_Conta, "", DateOnly.FromDateTime(DateTime.Today), "", "", "");
                                    Dados.ListaResidentes.Add(novoResidente);

                                    // Atualizar status
                                    solicitacaoParaEditar.status = 1;
                                }

                                break;

                            default:
                                Console.WriteLine("Tipo não existente!");
                                solicitacaoParaEditar.status = 0;
                                break;
                        }

                    }
                    // Rejeitou
                    else
                    {
                        solicitacaoParaEditar.status = 2;
                    }
                }
            }
            else
            {
                Console.WriteLine("Solicitacão não encontrada!");
            }
            Console.WriteLine("-----------");
        }

        public static void PropostaAtualizarFuncionario()
        {
            Console.WriteLine("\n-----------");
            Console.WriteLine("Atualizar Solicitação:");

            // Solicitar ao usuário o ID da solicitacao a ser atualizada
            Console.Write("ID da Solicitação a ser atualizada: ");
            int ID_Solicitacao_Find = int.Parse(Console.ReadLine());

            // Procurar solicitação na lista pelo id
            Solicitacao solicitacaoParaEditar = Dados.ListaSolicitacoes.Find(r => r.ID_solicitacao.Equals(ID_Solicitacao_Find));

            // Procurar funcionario na lista pelo id
            IFuncionario funcionarioEncontrar = Dados.ListaFuncionarios.Find(r => r.ID_Conta.Equals(SistemaLogin.ID_logado));

            switch(funcionarioEncontrar.tipoServ)
            {
                case 1:
                    // Limpeza

                    // Atualizar status
                    solicitacaoParaEditar.status = 1;
                    break;
                case 2:
                    // Manutencao

                    // Atualizar status
                    solicitacaoParaEditar.status = 1;
                    break;
                default:
                    Console.WriteLine("Opção Inválida!");
                    break;
            }
        }

        public static void PropostaListarFuncionario(List<Solicitacao> listaSolicitacoes)
        {
            Console.WriteLine("\n Lista Propostas:");
            Console.WriteLine("-----------");

            foreach (Solicitacao solicitacao in listaSolicitacoes)
            {
                if (solicitacao.tipoSolicitacao == 3 || solicitacao.tipoSolicitacao == 4)
                {
                    Console.WriteLine("ID Proposta: {0}", solicitacao.ID_solicitacao);
                    switch (solicitacao.tipoSolicitacao)
                    {
                        // Realocar Quarto
                        case 1:
                            Console.WriteLine("Tipo: Realocação Quarto ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Trocar Quarto
                        case 2:
                            Console.WriteLine("Tipo: Candidatura ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Requerir Limpeza
                        case 3:
                            Console.WriteLine("Tipo: Requisição Limpeza ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Requerir Manutenção
                        case 4:
                            Console.WriteLine("Tipo: Requisição Manutenção ({0})", solicitacao.tipoSolicitacao);
                            break;
                    }
                    Console.WriteLine("Data: {0}", solicitacao.dataSolicitacao);
                    Console.WriteLine("ID Conta: {0}", solicitacao.ID_Conta);
                    if (solicitacao.status == 0)
                    {
                        Console.WriteLine("Status: Por Responder");
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                    }
                    else if (solicitacao.status == 1)
                    {
                        if (solicitacao.tipoSolicitacao >= 1 && solicitacao.tipoSolicitacao <= 2)
                        {
                            Console.WriteLine("Status: Aceito");
                        }
                        if (solicitacao.tipoSolicitacao >= 3 && solicitacao.tipoSolicitacao <= 4)
                        {
                            Console.WriteLine("Status: Concluído");
                        }
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                        Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                    }
                    else if (solicitacao.status == 2)
                    {
                        Console.WriteLine("Status: Rejeitado");
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                        Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                    }

                    Console.WriteLine("-----------\n");
                }
            }
        }

        public static void PropostaListarResidente(List<Solicitacao> listaSolicitacoes)
        {
            Console.WriteLine("\n Lista Propostas:");
            Console.WriteLine("-----------");

            foreach (Solicitacao solicitacao in listaSolicitacoes)
            {
                if (solicitacao.ID_Conta == SistemaLogin.ID_logado)
                {
                    Console.WriteLine("ID Proposta: {0}", solicitacao.ID_solicitacao);
                    switch (solicitacao.tipoSolicitacao)
                    {
                        // Realocar Quarto
                        case 1:
                            Console.WriteLine("Tipo: Realocação Quarto ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Trocar Quarto
                        case 2:
                            Console.WriteLine("Tipo: Candidatura ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Requerir Limpeza
                        case 3:
                            Console.WriteLine("Tipo: Requisição Limpeza ({0})", solicitacao.tipoSolicitacao);
                            break;
                        // Requerir Manutenção
                        case 4:
                            Console.WriteLine("Tipo: Requisição Manutenção ({0})", solicitacao.tipoSolicitacao);
                            break;
                    }
                    Console.WriteLine("Data: {0}", solicitacao.dataSolicitacao);
                    Console.WriteLine("ID Conta: {0}", solicitacao.ID_Conta);
                    if (solicitacao.status == 0)
                    {
                        Console.WriteLine("Status: Por Responder");
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                    }
                    else if (solicitacao.status == 1)
                    {
                        if (solicitacao.tipoSolicitacao >= 1 && solicitacao.tipoSolicitacao <= 2)
                        {
                            Console.WriteLine("Status: Aceito");
                        }
                        if (solicitacao.tipoSolicitacao >= 3 && solicitacao.tipoSolicitacao <= 4)
                        {
                            Console.WriteLine("Status: Concluído");
                        }
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                        Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                    }
                    else if (solicitacao.status == 2)
                    {
                        Console.WriteLine("Status: Rejeitado");
                        Console.WriteLine("Justificação: \n{0}", solicitacao.justificacao);
                        Console.WriteLine("Resposta: \n{0}", solicitacao.resposta);
                    }

                    Console.WriteLine("-----------\n");
                }
            }
        }

        public static void ProporSolicitacaoFuncionario(int ID_Conta, int tipoProposta)
        {
            Console.Write("ID Proposta: ");
            int id_proposta = int.Parse(Console.ReadLine());
            Console.WriteLine("Justificacao: ");
            string justificacao = Console.ReadLine();

            if (tipoProposta == 3)
            {
                Solicitacao novaSolicitacao = new Solicitacao(id_proposta, 3, DateOnly.FromDateTime(DateTime.Today), ID_Conta, justificacao, 0, "");
                Dados.ListaSolicitacoes.Add(novaSolicitacao);
            }
            if (tipoProposta == 4)
            {
                Solicitacao novaSolicitacao = new Solicitacao(id_proposta, 4, DateOnly.FromDateTime(DateTime.Today), ID_Conta, justificacao, 0, "");
                Dados.ListaSolicitacoes.Add(novaSolicitacao);
            }
        }

        public static void CandidaturaAdicionarCandidato(List<Candidatura> listaCandidatura, int ID_Conta)
        {
            Console.WriteLine("\n Adicionar Candidatura:");
            Console.WriteLine("-----------");

            // Solicitar ID candidatura
            int id_candidatura = -1;
            while (id_candidatura == -1 || listaCandidatura.Any(r => r.ID_candidatura == id_candidatura))
            {
                Console.Write("ID Candidatura: ");
                id_candidatura = int.Parse(Console.ReadLine());
            }

            ICandidato candidatoachar = Dados.ListaCandidatos.Find(r => r.ID_Conta.Equals(ID_Conta));

            // Solicitar Data de Nascimento
            Console.WriteLine("Data (ano, mês, dia): ");
            DateOnly data = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            Candidatura novaCandidatura = new Candidatura(id_candidatura, candidatoachar.ID_cantidato, data);
            listaCandidatura.Add(novaCandidatura);
            Solicitacao novaProposta = new Solicitacao(id_candidatura + 1000, 2, DateOnly.FromDateTime(DateTime.Today), candidatoachar.ID_cantidato, "Candidatura: " + candidatoachar.ID_Conta, 0, "");
            Dados.ListaSolicitacoes.Add(novaProposta);

            Console.WriteLine("-----------\n");
        }

    }
}
