﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

using Projeto_POO.Classes;

namespace Projeto_POO.Funcoes
{
    public class SistemaLogin
    {
        // dados temporários armazenados no Login
        public static int ID_logado {  get; set; } // Id da conta
        public static int Modo { get; set; } // Modo de edição escolhido
        /*
         * 1-Residente
         * 2-Candidato
         * 3-Administrador
         * 4-Funcionario
         */

        public static void Login()
        {
            bool loginBemSucedido = false;

            while (!loginBemSucedido)
            {
                Console.WriteLine("\nLogin\n-----------");

                Console.Write("Utilizador (0=sair): ");
                string username = Console.ReadLine();

                if (username == "0")
                {
                    Environment.Exit(0);
                }

                Console.Write("Senha: ");
                string senha = Console.ReadLine();

                IConta contaLogada = Dados.ListaContas.FirstOrDefault(conta => conta.utilizador == username && conta.senha == senha);

                if (contaLogada != null)
                {
                    ID_logado = contaLogada.ID_Conta;
                    Console.WriteLine($"Login bem-sucedido! ID logado: {ID_logado}\n");
                    loginBemSucedido = true;

                    int admin_check = -1;
                    int residente_check = -1;
                    int candidato_check = -1;
                    int funcionario_check = -1;

                    int check = -1;
                    while (check == -1)
                    {

                        Console.WriteLine("Selecione o modo: ");
                        admin_check = -1;
                        residente_check = -1;
                        candidato_check = -1;
                        funcionario_check = -1;
                        // Selecionar Modo
                        foreach (IAdministrador administrador in Dados.ListaAdministradores)
                        {
                            if (administrador.ID_Conta == ID_logado)
                            {
                                Console.WriteLine("1 - Administrador");
                                admin_check = 1;
                            }
                        }
                        foreach (IResidente residente in Dados.ListaResidentes)
                        {
                            if (residente.ID_Conta == ID_logado)
                            {
                                Console.WriteLine("2 - Residente");
                                residente_check = 1;
                            }
                        }
                        foreach (ICandidato candidato in Dados.ListaCandidatos)
                        {
                            if (candidato.ID_Conta == ID_logado)
                            {
                                Console.WriteLine("3 - Candidato");
                                candidato_check = 1;
                            }
                        }
                        foreach (IFuncionario funcionario in Dados.ListaFuncionarios)
                        {
                            if (funcionario.ID_Conta == ID_logado)
                            {
                                Console.WriteLine("4 - Funcionário");
                                funcionario_check = 1;
                            }
                        }

                        Console.Write("Modo: ");
                        check = int.Parse(Console.ReadLine());
                        if (check == 1 && admin_check == 1)
                        {
                            Console.WriteLine("\nModo Administrador Selecionado!");
                            Modo = check;
                        }
                        else if (check == 2 && residente_check == 1)
                        {
                            Console.WriteLine("\nModo Residente Selecionado!");
                            Modo = check;
                        }
                        else if (check == 3 && candidato_check == 1)
                        {
                            Console.WriteLine("\nModo Candidato Selecionado!");
                            Modo = check;
                        }
                        else if (check == 4 && funcionario_check == 1)
                        {
                            Console.WriteLine("\nModo Funcionario Selecionado!");
                            Modo = check;
                        }
                        else
                        {
                            check = -1;
                        }

                    }
                }
                else
                {
                    Console.WriteLine("\nLogin falhou!");
                }
                Console.WriteLine("-----------\n");
            }
        }
    }
}
