﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

using Projeto_POO.Classes.Conta;
using Projeto_POO.Classes;
using CsvHelper.Configuration;
using CsvHelper;
using System.Globalization;
using Projeto_POO.Classes.Residencia.Pessoa;
using Projeto_POO.Classes.Residencia.Quarto;
using Projeto_POO.Classes.Servico;
using Microsoft.Data.SqlClient;

namespace Projeto_POO.Funcoes
{
    public class CSV_BD
    {
        public static void CSVChamadaLer()
        {
            Dados.ListaContas = CSV_BD.CSVCarregarDados<IConta, Conta>("contas.csv");
            Dados.ListaMoradas = CSV_BD.CSVCarregarDados<IMorada, Morada>("moradas.csv");
            Dados.ListaContaMorada = CSV_BD.CSVCarregarDados<ContaMorada, ContaMorada>("contamoradas.csv"); // ERRO resolvido
            Dados.ListaContactos = CSV_BD.CSVCarregarDados<IContacto, Contacto>("contactos.csv");
            Dados.ListaContaContacto = CSV_BD.CSVCarregarDados<ContaContacto, ContaContacto>("contacontactos.csv"); //ERRO resolvido
            Dados.ListaResidentes = CSV_BD.CSVCarregarDados<IResidente, Residente>("residentes.csv"); //ERRO resolvido
            Dados.ListaCandidatos = CSV_BD.CSVCarregarDados<ICandidato, Candidato>("candidatos.csv"); //ERRO resolvido
            Dados.ListaCandidatura = CSV_BD.CSVCarregarDados<Candidatura, Candidatura>("candidaturas.csv");
            Dados.ListaAdministradores = CSV_BD.CSVCarregarDados<IAdministrador, Administrador>("administradores.csv"); //ERRO resolvido
            Dados.ListaFuncionarios = CSV_BD.CSVCarregarDados<IFuncionario, Funcionario>("funcionarios.csv"); //ERRO resolvido
            Dados.ListaQuartos = CSV_BD.CSVCarregarDados<IQuarto, Quarto>("quartos.csv");
            Dados.ListaQuartoResidente = CSV_BD.CSVCarregarDados<QuartoResidente, QuartoResidente>("quartoresidentes.csv"); //ERRO resolvido
            Dados.ListaSolicitacoes = CSV_BD.CSVCarregarDados<Solicitacao, Solicitacao>("solicitacoes.csv");
        }

        public static void CSVChamadaEscrever()
        {
            CSVSalvarDados("contas.csv", Dados.ListaContas);
            CSVSalvarDados("moradas.csv", Dados.ListaMoradas);
            CSVSalvarDados("contamoradas.csv", Dados.ListaContaMorada);
            CSVSalvarDados("contactos.csv", Dados.ListaContactos);
            CSVSalvarDados("contacontactos.csv", Dados.ListaContaContacto);
            CSVSalvarDados("residentes.csv", Dados.ListaResidentes);
            CSVSalvarDados("candidatos.csv", Dados.ListaCandidatos);
            CSVSalvarDados("candidaturas.csv", Dados.ListaCandidatura);
            CSVSalvarDados("administradores.csv", Dados.ListaAdministradores);
            CSVSalvarDados("funcionarios.csv", Dados.ListaFuncionarios);
            CSVSalvarDados("quartos.csv", Dados.ListaQuartos);
            CSVSalvarDados("quartoresidentes.csv", Dados.ListaQuartoResidente);
            CSVSalvarDados("solicitacoes.csv", Dados.ListaSolicitacoes);
        }

        public static void BDChamadaLer()
        {
            // Ler dados na BD e inserir CSV
            CSV_BD.BDCarregarDados("Conta", "Dados/contas.csv");
            CSV_BD.BDCarregarDados("Morada", "Dados/moradas.csv");
            CSV_BD.BDCarregarDados("ContaMorada", "Dados/contamoradas.csv");
            CSV_BD.BDCarregarDados("Contacto", "Dados/contactos.csv");
            CSV_BD.BDCarregarDados("ContaContacto", "Dados/contacontactos.csv");
            CSV_BD.BDCarregarDados("Residente", "Dados/residentes.csv");
            CSV_BD.BDCarregarDados("Candidato", "Dados/candidatos.csv");
            CSV_BD.BDCarregarDados("Candidatura", "Dados/candidaturas.csv");
            CSV_BD.BDCarregarDados("Administrador", "Dados/administradores.csv");
            CSV_BD.BDCarregarDados("Funcionario", "Dados/funcionarios.csv");
            CSV_BD.BDCarregarDados("Quarto", "Dados/quartos.csv");
            CSV_BD.BDCarregarDados("QuartoResidente", "Dados/quartoresidentes.csv");
            CSV_BD.BDCarregarDados("Solicitacao", "Dados/solicitacoes.csv");
        }

        public static void BDChamadaEscrever()
        {
            // Gerar SQL para as tabelas
            string SQLConta = CSV_BD.BDGerarSQL("Conta", Dados.ListaContas);
            Console.WriteLine(SQLConta);
            string SQLMorada = CSV_BD.BDGerarSQL("Morada", Dados.ListaMoradas);
            //Console.WriteLine(SQLMorada);
            string SQLContaMorada = CSV_BD.BDGerarSQL("ContaMorada", Dados.ListaContaMorada);
            //Console.WriteLine(SQLContaMorada);
            string SQLContacto = CSV_BD.BDGerarSQL("Contacto", Dados.ListaContactos);
            //Console.WriteLine(SQLContacto);
            string SQLContaContacto = CSV_BD.BDGerarSQL("ContaContacto", Dados.ListaContaContacto);
            //Console.WriteLine(SQLContaContacto);
            string SQLResidente = CSV_BD.BDGerarSQL("Residente", Dados.ListaResidentes);
            Console.WriteLine(SQLResidente);
            string SQLCandidato = CSV_BD.BDGerarSQL("Candidato", Dados.ListaCandidatos);
            Console.WriteLine(SQLCandidato);
            string SQLCandidatura = CSV_BD.BDGerarSQL("Candidatura", Dados.ListaCandidatura);
            //Console.WriteLine(SQLCandidatura);
            string SQLAdministrador = CSV_BD.BDGerarSQL("Administrador", Dados.ListaAdministradores);
            Console.WriteLine(SQLAdministrador);
            string SQLFuncionario = CSV_BD.BDGerarSQL("Funcionario", Dados.ListaFuncionarios);
            Console.WriteLine(SQLFuncionario);
            string SQLQuarto = CSV_BD.BDGerarSQL("Quarto", Dados.ListaQuartos);
            //Console.WriteLine(SQLQuarto);
            string SQLQuartoResidente = CSV_BD.BDGerarSQL("QuartoResidente", Dados.ListaQuartoResidente);
            //Console.WriteLine(SQLQuartoResidente);
            string SQLSolicitacao = CSV_BD.BDGerarSQL("Solicitacao", Dados.ListaSolicitacoes);
            //Console.WriteLine(SQLSolicitacao);


            // Inserir dados na BD
            CSV_BD.BDSalvarDados(SQLConta, "Conta");
            CSV_BD.BDSalvarDados(SQLMorada, "Morada");
            CSV_BD.BDSalvarDados2(SQLContaMorada, "ContaMorada");
            CSV_BD.BDSalvarDados(SQLContacto, "Contacto");
            CSV_BD.BDSalvarDados2(SQLContaContacto, "ContaContacto");
            CSV_BD.BDSalvarDados(SQLResidente, "Residente");
            CSV_BD.BDSalvarDados(SQLCandidato, "Candidato");
            CSV_BD.BDSalvarDados(SQLCandidatura, "Candidatura");
            CSV_BD.BDSalvarDados(SQLAdministrador, "Administrador");
            CSV_BD.BDSalvarDados(SQLFuncionario, "Funcionario");
            CSV_BD.BDSalvarDados(SQLQuarto, "Quarto");
            CSV_BD.BDSalvarDados2(SQLQuartoResidente, "QuartoResidente");
            CSV_BD.BDSalvarDados(SQLSolicitacao, "Solicitacao");
        }

        // FUNCOES

        // gerir CSV
        // Função genérica para Salvar Dados
        public static void CSVSalvarDados<T>(string nomeArquivo, List<T> lista)
        {
            // Caminho do diretório
            string diretorio = "Dados";

            // Verificar se o diretório existe, caso contrário, criá-lo
            if (!Directory.Exists(diretorio))
            {
                Directory.CreateDirectory(diretorio);
            }

            // Caminho completo do arquivo
            string nomeCaminho = Path.Combine(diretorio, nomeArquivo);

            using (var writer = new StreamWriter(nomeCaminho))
            using (var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture)))
            {
                csv.WriteRecords(lista);
            }
        }

        // Função de leitura CSV para cada lista do projeto
        public static List<TInterface> CSVCarregarDados<TInterface, TClass>(string nomeArquivo)
        where TInterface : class
        where TClass : class, TInterface
        {
            List<TInterface> listaCarregada = new List<TInterface>();

            // Caminho do diretório
            string diretorio = "Dados";

            // Caminho completo do arquivo
            string nomeCaminho = Path.Combine(diretorio, nomeArquivo);

            if (File.Exists(nomeCaminho))
            {
                var config = new CsvConfiguration(CultureInfo.InvariantCulture)
                {
                    // Configuração para ignorar a validação de cabeçalhos ausentes
                    HeaderValidated = null,
                    MissingFieldFound = null
                };

                using (var reader = new StreamReader(nomeCaminho))
                using (var csv = new CsvReader(reader, config))
                {
                    listaCarregada.AddRange(csv.GetRecords<TClass>().Cast<TInterface>());
                }
            }

            return listaCarregada;
        }

        // ---

        // gerir BD
        // Converter base de dados em SQL
        public static string BDGerarSQL<T>(string nomeTabela, List<T> lista)
        {
            if (lista == null || lista.Count == 0)
            {
                return string.Empty;
            }

            var tipoObjeto = lista[0].GetType();
            var propriedades = tipoObjeto.GetProperties();

            var valores = lista.Select(objeto =>
            {
                var valoresPropriedades = propriedades.Select(propriedade =>
                {
                    var valor = propriedade.GetValue(objeto);
                    if (valor == null)
                    {
                        return "NULL";
                    }

                    if (propriedade.PropertyType == typeof(string) || propriedade.PropertyType == typeof(DateTime))
                    {
                        return $"'{valor}'";
                    }

                    return valor.ToString();
                });

                return $"({string.Join(", ", valoresPropriedades)})";
            });

            var colunas = propriedades.Select(propriedade => propriedade.Name);
            var sqlInsert = $"INSERT INTO {nomeTabela} ({string.Join(", ", colunas)}) VALUES {string.Join(", ", valores)};";

            return sqlInsert;
        }

        // Função genérica para Salvar Dados
        public static void BDSalvarDados(string sqlInsert, string nomeTabela)
        {
            // Sua connection string
            string connectionString = "Data Source=DU-PC\\MSSQLSERVER2;Initial Catalog=poobd;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Remover todos os dados da tabela
                    using (SqlCommand deleteAllData = new SqlCommand($"DELETE FROM {nomeTabela}", connection))
                    {
                        deleteAllData.ExecuteNonQuery();
                    }

                    // Ativar temporariamente a opção IDENTITY_INSERT
                    using (SqlCommand enableIdentityInsert = new SqlCommand($"SET IDENTITY_INSERT {nomeTabela} ON", connection))
                    {
                        enableIdentityInsert.ExecuteNonQuery();
                    }

                    // Executar o comando SQL
                    using (SqlCommand command = new SqlCommand(sqlInsert, connection))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine($"Dados inseridos na tabela {nomeTabela} com sucesso!");
                    }

                    // Desativar a opção IDENTITY_INSERT após a inserção
                    using (SqlCommand disableIdentityInsert = new SqlCommand($"SET IDENTITY_INSERT {nomeTabela} OFF", connection))
                    {
                        disableIdentityInsert.ExecuteNonQuery();
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao inserir dados na tabela {nomeTabela}: {ex.Message}");
                }
            }
        }

        // Função genéria para Salvar dados sem o (identity set->chave primária)
        public static void BDSalvarDados2(string sqlInsert, string nomeTabela)
        {
            // Sua connection string
            string connectionString = "Data Source=DU-PC\\MSSQLSERVER2;Initial Catalog=poobd;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Remover todos os dados da tabela
                    using (SqlCommand deleteAllData = new SqlCommand($"DELETE FROM {nomeTabela}", connection))
                    {
                        deleteAllData.ExecuteNonQuery();
                    }

                    // Executar o comando SQL
                    using (SqlCommand command = new SqlCommand(sqlInsert, connection))
                    {
                        command.ExecuteNonQuery();
                        Console.WriteLine($"Dados inseridos na tabela {nomeTabela} com sucesso!");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao inserir dados na tabela {nomeTabela}: {ex.Message}");
                }
            }
        }

        // Função de leitura BD->CSV para cada tabela da BD
        public static void BDCarregarDados(string nomeTabela, string caminhoArquivoCSV)
        {
            // Sua connection string
            string connectionString = "Data Source=DU-PC\\MSSQLSERVER2;Initial Catalog=poobd;Integrated Security=True;TrustServerCertificate=True;";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();

                    // Consulta SQL para selecionar todos os dados da tabela
                    string sqlQuery = $"SELECT * FROM {nomeTabela}";

                    using (SqlCommand command = new SqlCommand(sqlQuery, connection))
                    {
                        using (SqlDataReader reader = command.ExecuteReader())
                        {
                            if (reader.HasRows)
                            {
                                // Configurar o escritor CSV
                                using (var writer = new StreamWriter(caminhoArquivoCSV))
                                using (var csv = new CsvWriter(writer, new CsvConfiguration(CultureInfo.InvariantCulture)))
                                {
                                    // Escrever o cabeçalho (nomes das colunas)
                                    for (int i = 0; i < reader.FieldCount; i++)
                                    {
                                        csv.WriteField(reader.GetName(i));
                                    }
                                    csv.NextRecord();

                                    // Escrever os dados
                                    while (reader.Read())
                                    {
                                        for (int i = 0; i < reader.FieldCount; i++)
                                        {
                                            // Remover espaços em branco e ajustar a string "00:00:00"
                                            string fieldValue = reader.GetValue(i).ToString().Trim();
                                            if (!string.IsNullOrEmpty(fieldValue) && fieldValue.Contains("00:00:00"))
                                            {
                                                // Se contiver "00:00:00", manter apenas a parte antes dele
                                                DateTime dateTimeValue;
                                                if (DateTime.TryParse(fieldValue, out dateTimeValue))
                                                {
                                                    csv.WriteField(dateTimeValue.ToString("dd/MM/yyyy"));
                                                }
                                                else
                                                {
                                                    // Se não for possível converter para DateTime, manter o valor original
                                                    csv.WriteField(fieldValue);
                                                }
                                            }
                                            else
                                            {
                                                // Se não contiver "00:00:00" ou for uma string vazia, manter o valor original
                                                csv.WriteField(fieldValue);
                                            }
                                        }

                                        csv.NextRecord();
                                    }
                                }

                                Console.WriteLine($"Dados da tabela {nomeTabela} exportados para {caminhoArquivoCSV} com sucesso!");
                            }
                            else
                            {
                                Console.WriteLine($"A tabela {nomeTabela} não possui dados.");
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Erro ao exportar dados da tabela {nomeTabela} para CSV: {ex.Message}");
                }
            }
        }
    }
}
