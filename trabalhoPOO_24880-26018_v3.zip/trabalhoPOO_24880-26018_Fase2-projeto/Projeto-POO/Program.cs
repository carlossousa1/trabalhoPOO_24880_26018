﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

using Projeto_POO.Classes.Servico;
using Projeto_POO.Funcoes;

namespace Projeto_POO.Classes.Conta
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Ler ficheiro CSV
            CSV_BD.CSVChamadaLer();

            // Conta Predefinida no Programa (para testes)
            //IConta novaConta = new Conta(999, "teste", new DateOnly(1900, 1, 1), "M", "admin", "123");
            //IAdministrador novoAdmin = new Administrador(999, 999, "", new DateOnly(1900, 1, 1), "", "", "");
            //Dados.ListaContas.Add(novaConta);
            //Dados.ListaAdministradores.Add(novoAdmin);

            // Menu com Modos
            while (true)
            {
            exit_loop:
                SistemaLogin.Login();
                int opcao = 0;

                #region Modo Admin
                if ((SistemaLogin.Modo) == 1)
                {
                    int admin_modo = 1;

                    while (true)
                    {
                        switch (admin_modo)
                        {
                            // Modo Principal
                            case 1:
                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Início (1)");
                                Console.WriteLine("1. Ver/Alterar Perfil");
                                Console.WriteLine("2. Gerir Solicitações");
                                Console.WriteLine("3. ler CSV");
                                Console.WriteLine("4. Atualizar CSV");
                                Console.WriteLine("5. Ler BD");
                                Console.WriteLine("6. Atualizar BD");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());
                                
                                if (opcao == 1)
                                {
                                    GestaoDados.PerfilListar();
                                }
                                if (opcao == 2)
                                {
                                    int opcao2 = -1;
                                    while (opcao2 != 0)
                                    {
                                        Console.WriteLine("\n-----------");
                                        Console.WriteLine("Gestão de Propostas/Candidaturas");
                                        Console.WriteLine("1. Listar Propostas");
                                        Console.WriteLine("2. Atualizar Proposta");
                                        Console.WriteLine("0. Sair");
                                        Console.Write("Opcao: ");
                                        opcao2 = int.Parse(Console.ReadLine());
                                        if (opcao2 == 1)
                                        {
                                            GestaoDados.PropostaListar(Dados.ListaSolicitacoes);
                                            GestaoDados.CandidaturaListar(Dados.ListaCandidatura);
                                        }
                                        if (opcao2 == 2)
                                        {
                                            GestaoDados.PropostaAtualizar();
                                        }
                                        if (opcao2 == 0)
                                        {
                                            // saiu
                                        }
                                    }
                                }
                                if (opcao == 3)
                                {
                                    CSV_BD.CSVChamadaLer();
                                    Console.WriteLine("Dados CSV Lidos!");
                                }
                                if (opcao == 4)
                                {
                                    CSV_BD.CSVChamadaEscrever();
                                    Console.WriteLine("Dados CSV Atualizados!");
                                }
                                if (opcao == 5)
                                {
                                    CSV_BD.BDChamadaLer();
                                    Console.WriteLine("Dados BD Lidos!");
                                    CSV_BD.CSVChamadaLer();
                                    Console.WriteLine("Dados CSV Lidos!");
                                }
                                if (opcao == 6)
                                {
                                    CSV_BD.BDChamadaEscrever();
                                    Console.WriteLine("Dados BD Atualizados!");
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Conta
                            case 2:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Conta (2)");
                                Console.WriteLine("1. Listar Contas");
                                Console.WriteLine("11. Adicionar Conta");
                                Console.WriteLine("12. Remover Conta");
                                Console.WriteLine("2. Listar Contactos");
                                Console.WriteLine("21. Adicionar Contacto");
                                Console.WriteLine("22. Remover Contacto");
                                Console.WriteLine("23. Vincular/Desvincular Contacto");
                                Console.WriteLine("3. Listar Moradas");
                                Console.WriteLine("31. Adicionar Morada");
                                Console.WriteLine("32. Remover Morada");
                                Console.WriteLine("33. Vincular/Desvincular Morada");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.ContaListar(Dados.ListaContas);
                                }
                                if (opcao == 11)
                                {
                                    GestaoDados.ContaAdicionar(Dados.ListaContas);
                                }
                                if (opcao == 12)
                                {
                                    GestaoDados.ContaRemover(Dados.ListaContas);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.ContactoListar(Dados.ListaContactos);
                                }
                                if (opcao == 21)
                                {
                                    GestaoDados.ContactoAdicionar(Dados.ListaContactos);
                                }
                                if (opcao == 22)
                                {
                                    GestaoDados.ContactoRemover(Dados.ListaContactos);
                                }
                                if (opcao == 23)
                                {
                                    int modo_vincular = 0;
                                    int opcao_vincular1 = 0;
                                    int opcao_vincular2 = 0;
                                    Console.Write("ID Conta: ");
                                    opcao_vincular1 = int.Parse(Console.ReadLine());
                                    Console.Write("ID Contacto: ");
                                    opcao_vincular2 = int.Parse(Console.ReadLine());

                                    Console.WriteLine("\nVincular(1)/Desvincular(2)");
                                    Console.Write("Modo: ");
                                    modo_vincular = int.Parse(Console.ReadLine());

                                    if (modo_vincular == 1)
                                    {
                                        GestaoDados.ContaVincularContacto(opcao_vincular1, opcao_vincular2);
                                    }
                                    else if (modo_vincular == 2)
                                    {
                                        GestaoDados.ContaDesvincularContacto(opcao_vincular1, opcao_vincular2);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Opção Inválida!\n");
                                    }
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.MoradaListar(Dados.ListaMoradas);
                                }
                                if (opcao == 31)
                                {
                                    GestaoDados.MoradaAdicionar(Dados.ListaMoradas);
                                }
                                if (opcao == 32)
                                {
                                    GestaoDados.MoradaRemover(Dados.ListaMoradas);
                                }
                                if (opcao == 33)
                                {
                                    int modo_vincular = 0;
                                    int opcao_vincular1 = 0;
                                    int opcao_vincular2 = 0;
                                    Console.Write("ID Conta: ");
                                    opcao_vincular1 = int.Parse(Console.ReadLine());
                                    Console.Write("ID Morada: ");
                                    opcao_vincular2 = int.Parse(Console.ReadLine());

                                    Console.WriteLine("\nVincular(1)/Desvincular(2)");
                                    Console.Write("Modo: ");
                                    modo_vincular = int.Parse(Console.ReadLine());

                                    if (modo_vincular == 1)
                                    {
                                        GestaoDados.ContaVincularMorada(opcao_vincular1, opcao_vincular2);
                                    }
                                    else if (modo_vincular == 2)
                                    {
                                        GestaoDados.ContaDesvincularMorada(opcao_vincular1, opcao_vincular2);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Opção Inválida!\n");
                                    }
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Residente
                            case 3:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Residente (3)");
                                Console.WriteLine("1. Listar Residente");
                                Console.WriteLine("2. Adicionar Residente");
                                Console.WriteLine("3. Remover Residente");
                                Console.WriteLine("4. Residente Ocupar/Desocupar");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.ResidenteListar(Dados.ListaResidentes);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.ResidenteAdicionar(Dados.ListaResidentes);
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.ResidenteRemover(Dados.ListaResidentes);
                                }
                                if (opcao == 4)
                                {
                                    int modo_vincular = 0;
                                    int opcao_vincular1 = 0;
                                    int opcao_vincular2 = 0;
                                    Console.Write("ID Residente: ");
                                    opcao_vincular1 = int.Parse(Console.ReadLine());
                                    Console.Write("ID Quarto: ");
                                    opcao_vincular2 = int.Parse(Console.ReadLine());

                                    Console.WriteLine("\nOcupar(1)/Desocupar(2)");
                                    Console.Write("Modo: ");
                                    modo_vincular = int.Parse(Console.ReadLine());

                                    if (modo_vincular == 1)
                                    {
                                        GestaoDados.ResidenteOcupar(opcao_vincular1, opcao_vincular2);
                                    }
                                    else if (modo_vincular == 2)
                                    {
                                        GestaoDados.ResidenteDesocupar(opcao_vincular1, opcao_vincular2);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Opção Inválida!\n");
                                    }
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Candidato
                            case 4:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Candidato (4)");
                                Console.WriteLine("1. Listar Candidato");
                                Console.WriteLine("11. Adicionar Candidato");
                                Console.WriteLine("12. Remover Candidato");
                                Console.WriteLine("2. Listar Candidatura");
                                Console.WriteLine("21. Adicionar Candidatura");
                                Console.WriteLine("22. Remover Candidatura");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.CandidatoListar(Dados.ListaCandidatos);
                                }
                                if (opcao == 11)
                                {
                                    GestaoDados.CandidatoAdicionar(Dados.ListaCandidatos);
                                }
                                if (opcao == 12)
                                {
                                    GestaoDados.CandidatoRemover(Dados.ListaCandidatos);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.CandidaturaListar(Dados.ListaCandidatura);
                                }
                                if (opcao == 21)
                                {
                                    GestaoDados.CandidaturaAdicionar(Dados.ListaCandidatura);
                                }
                                if (opcao == 22)
                                {
                                    GestaoDados.CandidaturaRemover(Dados.ListaCandidatura);
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Funcionário
                            case 5:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Funcionário (5)");
                                Console.WriteLine("1. Listar Funcionário");
                                Console.WriteLine("2. Adicionar Funcionário");
                                Console.WriteLine("3. Remover Funcionário");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.FuncionarioListar(Dados.ListaFuncionarios);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.FuncionarioAdicionar(Dados.ListaFuncionarios);
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.FuncionarioRemover(Dados.ListaFuncionarios);
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Administrador
                            case 6:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Administrador (6)");
                                Console.WriteLine("1. Listar Administrador");
                                Console.WriteLine("2. Adicionar Administrador");
                                Console.WriteLine("3. Remover Administrador");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.AdministradorListar(Dados.ListaAdministradores);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.AdministradorAdicionar(Dados.ListaAdministradores);
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.AdministradorRemover(Dados.ListaAdministradores);
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Quarto/Alocação
                            case 7:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Quarto/Alocação (7)");
                                Console.WriteLine("1. Listar Quarto");
                                Console.WriteLine("2. Adicionar Quarto");
                                Console.WriteLine("3. Remover Quarto");
                                Console.WriteLine("4. Residente Ocupar/Desocupar");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.QuartoListar(Dados.ListaQuartos);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.QuartoAdicionar(Dados.ListaQuartos);
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.QuartoRemover(Dados.ListaQuartos);
                                }
                                if (opcao == 4)
                                {
                                    int modo_vincular = 0;
                                    int opcao_vincular1 = 0;
                                    int opcao_vincular2 = 0;
                                    Console.Write("ID Residente: ");
                                    opcao_vincular1 = int.Parse(Console.ReadLine());
                                    Console.Write("ID Quarto: ");
                                    opcao_vincular2 = int.Parse(Console.ReadLine());

                                    Console.WriteLine("\nOcupar(1)/Desocupar(2)");
                                    Console.Write("Modo: ");
                                    modo_vincular = int.Parse(Console.ReadLine());

                                    if (modo_vincular == 1)
                                    {
                                        GestaoDados.ResidenteOcupar(opcao_vincular1, opcao_vincular2);
                                    }
                                    else if (modo_vincular == 2)
                                    {
                                        GestaoDados.ResidenteDesocupar(opcao_vincular1, opcao_vincular2);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Opção Inválida!\n");
                                    }
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;

                            // Gestão: Proposta
                            case 8:

                                Console.WriteLine("\n-----------");
                                Console.WriteLine("Modo: Proposta (8)");
                                Console.WriteLine("1. Listar Propostas");
                                Console.WriteLine("2. Adicionar Proposta");
                                Console.WriteLine("3. Remover Proposta");
                                Console.WriteLine("9. Trocar Edição");
                                Console.WriteLine("0. Sair");
                                Console.Write("Opção: ");
                                opcao = int.Parse(Console.ReadLine());

                                if (opcao == 1)
                                {
                                    GestaoDados.PropostaListar(Dados.ListaSolicitacoes);
                                }
                                if (opcao == 2)
                                {
                                    GestaoDados.PropostaAdicionar(Dados.ListaSolicitacoes);
                                }
                                if (opcao == 3)
                                {
                                    GestaoDados.PropostaRemover(Dados.ListaSolicitacoes);
                                }
                                if (opcao == 9)
                                {
                                    while (true)
                                    {
                                        Console.WriteLine("1 - Menu Principal");
                                        Console.WriteLine("2 - Gestão Conta");
                                        Console.WriteLine("3 - Gestão Residente");
                                        Console.WriteLine("4 - Gestão Candidato");
                                        Console.WriteLine("5 - Gestão Funcionário");
                                        Console.WriteLine("6 - Gestão Administrador");
                                        Console.WriteLine("7 - Gestão Quarto/Alocação");
                                        Console.WriteLine("8 - Gestão Proposta");
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6 || admin_modo == 7 || admin_modo == 8) break;
                                    }
                                }
                                if (opcao == 0)
                                {
                                    goto exit_loop;
                                }

                                break;
                        }
                    }
                }
                #endregion

                #region Modo Residente
                if ((SistemaLogin.Modo) == 2)
                {
                    while (true)
                    {
                        Console.WriteLine("\n-----------");
                        Console.WriteLine("Modo: Início (1)");
                        Console.WriteLine("1. Ver/Alterar Perfil");
                        Console.WriteLine("2. Listar Solicitações");
                        Console.WriteLine("3. Enviar Solicitações");
                        Console.WriteLine("4. Solicitar Serviços");
                        Console.WriteLine("0. Sair");
                        Console.Write("Opção: ");
                        opcao = int.Parse(Console.ReadLine());

                        if (opcao == 1)
                        {
                            GestaoDados.PerfilListar();
                        }
                        if (opcao == 2)
                        {
                            GestaoDados.PropostaListarResidente(Dados.ListaSolicitacoes);
                        }
                        if (opcao == 3)
                        {
                            int opcao2, id_prop;
                            string justificacao;
                            Console.WriteLine("\n-----------");
                            Console.WriteLine("Pedir Solicitações");
                            Console.WriteLine("1. Pedir Realocação");
                            Console.WriteLine("0. Sair");
                            Console.Write("Opcao: ");
                            opcao2 = int.Parse(Console.ReadLine());
                            if (opcao2 == 1)
                            {
                                Console.WriteLine("Justificação: ");
                                justificacao = Console.ReadLine();
                                Console.Write("ID Solicitacao: ");
                                id_prop = int.Parse(Console.ReadLine());

                                Solicitacao novaSolicitacao = new Solicitacao(id_prop, 1, DateOnly.FromDateTime(DateTime.Today), SistemaLogin.ID_logado, justificacao, 0, "");
                                Dados.ListaSolicitacoes.Add(novaSolicitacao);
                            }
                            if (opcao2 == 0)
                            {
                                // saiu
                            }
                        }
                        if (opcao == 4)
                        {
                            int tipo_proposta = 0;
                            while (tipo_proposta == 0 || (tipo_proposta != 3 && tipo_proposta != 4))
                            {
                                Console.Write("Proposta (1-Limpeza, 2-Manutenção): ");
                                tipo_proposta = int.Parse(Console.ReadLine())+2;
                            }

                            GestaoDados.ProporSolicitacaoFuncionario(SistemaLogin.ID_logado, tipo_proposta);
                        }
                        if (opcao == 0)
                        {
                            goto exit_loop;
                        }
                    }
                }
                #endregion

                #region Modo Candidato
                if ((SistemaLogin.Modo) == 3)
                {
                    while (true)
                    {
                        Console.WriteLine("\n-----------");
                        Console.WriteLine("Modo: Início (1)");
                        Console.WriteLine("1. Ver/Alterar Perfil");
                        Console.WriteLine("2. Candidatar-se");
                        Console.WriteLine("0. Sair");
                        Console.Write("Opção: ");
                        opcao = int.Parse(Console.ReadLine());

                        if (opcao == 1)
                        {
                            GestaoDados.PerfilListar();
                        }
                        if (opcao == 2)
                        {
                            GestaoDados.CandidaturaAdicionarCandidato(Dados.ListaCandidatura, SistemaLogin.ID_logado);
                        }
                        if (opcao == 0)
                        {
                            goto exit_loop;
                        }
                    }
                }
                #endregion

                #region Modo Funcionario
                if ((SistemaLogin.Modo) == 4)
                {
                    while (true)
                    {
                        Console.WriteLine("\n-----------");
                        Console.WriteLine("Modo: Início (1)");
                        Console.WriteLine("1. Ver/Alterar Perfil");
                        Console.WriteLine("2. Listar Solicitações");
                        Console.WriteLine("3. Solucionar Proposta");
                        Console.WriteLine("0. Sair");
                        Console.Write("Opção: ");
                        opcao = int.Parse(Console.ReadLine());

                        if (opcao == 1)
                        {
                            GestaoDados.PerfilListar();
                        }
                        if (opcao == 2)
                        {
                            GestaoDados.PropostaListarFuncionario(Dados.ListaSolicitacoes);
                        }
                        if (opcao == 3)
                        {
                            GestaoDados.PropostaAtualizarFuncionario();
                        }
                        if (opcao == 0)
                        {
                            goto exit_loop;
                        }
                    }
                }
                #endregion
            }

        }

    }
}