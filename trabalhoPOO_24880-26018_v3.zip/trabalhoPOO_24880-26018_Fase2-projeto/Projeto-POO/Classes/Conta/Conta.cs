﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Conta
{
    // Conta
    internal class Conta : IConta
    {
        public int ID_Conta { get; set; }
        public string nome { get; set; }
        public DateOnly dataNasc { get; set; }
        public string genero { get; set; }
        public string utilizador { get; set; }
        public string senha { get; set; }

        public Conta(int ID_Conta, string nome, DateOnly dataNasc, string genero, string utilizador, string senha)
        {
            this.ID_Conta = ID_Conta;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;
            this.utilizador = utilizador;
            this.senha = senha;
        }
    }

    // Contacto
    internal class Contacto : IContacto
    {
        public int ID_contacto { get; set; }
        public string valor { get; set; }
        public string tipo_contacto { get; set; }

        public Contacto(int ID_contacto, string valor, string tipo_contacto)
        {
            this.ID_contacto = ID_contacto;
            this.valor = valor;
            this.tipo_contacto = tipo_contacto;
        }
    }

    // Ligacao Conta->Contacto
    public class ContaContacto
    {
        public int ID_conta { get; set; }
        public int ID_contacto { get; set; }

        public ContaContacto(int ID_conta, int ID_contacto)
        {
            this.ID_conta = ID_conta;
            this.ID_contacto = ID_contacto;
        }
    }

    // Morada
    internal class Morada : IMorada
    {
        public int ID_morada { get; set; }
        public string morada { get; set; }
        public string cod_postal { get; set; }

        public Morada(int ID_morada, string morada, string cod_postal)
        {
            this.ID_morada = ID_morada;
            this.morada = morada;
            this.cod_postal = cod_postal;
        }
    }

    // Ligacao Conta->Morada
    public class ContaMorada
    {
        public int ID_conta { get; set; }
        public int ID_morada { get; set; }

        public ContaMorada(int ID_conta, int ID_morada)
        {
            this.ID_conta = ID_conta;
            this.ID_morada = ID_morada;
        }
    }
}
