﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Servico
{
    public class Solicitacao
    {
        public int ID_solicitacao { get; set; }
        // Determinar o tipo de serviço
        public int tipoSolicitacao { get; set; }
        /*
         * 1-Realocação Quarto
         * 2-Limpeza
         * 3-Manutenção
         */
        public DateOnly dataSolicitacao { get; set; }
        public int ID_Conta { get; set; }
        public string justificacao {  get; set; }
        public int status { get; set; }
        public string resposta {  get; set; }

        public Solicitacao(int ID_solicitacao, int tipoSolicitacao, DateOnly dataSolicitacao, int ID_Conta, string justificacao, int status, string resposta)
        {
            this.ID_solicitacao = ID_solicitacao;
            this.tipoSolicitacao = tipoSolicitacao;
            this.dataSolicitacao = dataSolicitacao;
            this.ID_Conta = ID_Conta;
            this.justificacao = justificacao;
            this.status = status;
            this.resposta = resposta;
        }
    }
}
