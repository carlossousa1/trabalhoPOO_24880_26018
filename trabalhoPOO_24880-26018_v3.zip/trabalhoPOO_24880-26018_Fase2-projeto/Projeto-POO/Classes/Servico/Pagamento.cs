﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Servico
{
    internal class Pagamento
    {
        public int ID_Pagamento { get; set; }
        public int ID_Conta { get; set; }
        public DateOnly DataPagamento { get; set; }
        public int Valor { get; set; }

        public Pagamento(int ID_Pagamento, int ID_Conta, DateOnly DataPagamento, int Valor) 
        {
            this.ID_Pagamento = ID_Pagamento;
            this.ID_Conta = ID_Conta;
            this.DataPagamento = DataPagamento;
            this.Valor = Valor;
        }
    }
}
