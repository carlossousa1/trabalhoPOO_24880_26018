﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes
{
    // Grupo que contém a interface de todas classes utilizadas no projeto, com isso faz-se a junção de dados sejam eles públicos ou protegidos

    public interface IConta
    {
        int ID_Conta { get; set; }
        string nome { get; set; }
        DateOnly dataNasc { get; set; }
        string genero { get; set; }
        string utilizador { get; set; }
        string senha { get; set; }
    }

    public interface IContacto
    {
        int ID_contacto { get; set; }
        string valor { get; set; }
        string tipo_contacto { get; set; }
    }

    public interface IMorada
    {
        int ID_morada { get; set; }
        string morada { get; set; }
        string cod_postal { get; set; }
    }

    // ---

    public interface IResidente
    {
        int ID_residente { get; set; }
        int divida { get; set; }
        int ocupando { get; set; }
        int ID_Conta { get; set; }
        string nome { get; set; }
        DateOnly dataNasc { get; set; }
        string genero { get; set; }
        string utilizador { get; set; }
        string senha { get; set; }
    }

    public interface ICandidato
    {
        int ID_cantidato { get; set; }
        int estado { get; set; }
        int ID_Conta { get; set; }
        string nome { get; set; }
        DateOnly dataNasc { get; set; }
        string genero { get; set; }
        string utilizador { get; set; }
        string senha { get; set; }
    }

    public interface IAdministrador
    {
        int ID_admin {  get; set; }
        int ID_Conta { get; set; }
        string nome { get; set; }
        DateOnly dataNasc { get; set; }
        string genero { get; set; }
        string utilizador { get; set; }
        string senha { get; set; }
    }

    public interface IFuncionario
    {
        public int ID_funcionario { get; set; }
        public int tipoServ { get; set; }
        int ID_Conta { get; set; }
        string nome { get; set; }
        DateOnly dataNasc { get; set; }
        string genero { get; set; }
        string utilizador { get; set; }
        string senha { get; set; }
    }

    public interface IQuarto
    {
        int ID_quarto { get; set; }
        int tipoQuarto { get; set; }
        int lotacao { get; set; }
    }
}
