﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Residencia.Quarto
{
    // Quarto
    internal class Quarto : IQuarto
    {
        public int ID_quarto { get; set; }
        public int tipoQuarto { get; set; }
        public int lotacao { get; set; }

        public Quarto(int ID_quarto, int tipoQuarto, int lotacao)
        {
            this.ID_quarto = ID_quarto;
            this.tipoQuarto = tipoQuarto;
            this.lotacao = lotacao;
        }
    }

    // Ligacao Quarto->Residente
    public class QuartoResidente
    {
        public int ID_quarto { get; set; }
        public int ID_residente { get; set; }

        public QuartoResidente(int ID_quarto, int ID_residente)
        {
            this.ID_quarto = ID_quarto;
            this.ID_residente = ID_residente;
        }
    }
}
