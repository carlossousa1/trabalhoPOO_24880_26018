﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Residencia.Pessoa
{
    // Extrair classe externa
    using Conta;

    // Candidato
    internal class Candidato : Conta, ICandidato
    {
        public int ID_cantidato { get; set; }
        public int estado { get; set; }

        public Candidato(int ID_cantidato, int estado, int ID_Conta, string nome, DateOnly dataNasc, string genero, string utilizador, string senha)
            : base(ID_Conta, nome, dataNasc, genero, utilizador, senha)
        {
            this.ID_Conta = ID_Conta;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;

            this.ID_cantidato = ID_cantidato;
            this.estado = estado;
        }
    }

    // Candidatura
    public class Candidatura
    {
        public int ID_candidatura { get; set; }
        public int ID_candidato { get; set; }
        public DateOnly dataCandidatura { get; set; }

        public Candidatura(int ID_candidatura, int ID_candidato, DateOnly dataCandidatura)
        {
            // informacao exclusiva
            this.ID_candidatura = ID_candidatura;
            this.ID_candidato = ID_candidato;
            this.dataCandidatura = dataCandidatura;

        }
    }
}
