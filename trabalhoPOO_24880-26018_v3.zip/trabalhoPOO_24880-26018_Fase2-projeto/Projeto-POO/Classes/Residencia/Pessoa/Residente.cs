﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Residencia.Pessoa
{
    // Extrair classe externa
    using Conta;

    // Residente
    internal class Residente : Conta, IResidente
    {
        public int ID_residente { get; set; }
        public int divida { get; set; }
        public int ocupando { get; set; }

        public Residente(int ID_residente, int divida, int ocupando, int ID_Conta, string nome, DateOnly dataNasc, string genero, string utilizador, string senha)
            : base(ID_Conta, nome, dataNasc, genero, utilizador, senha)
        {
            this.ID_Conta = ID_Conta;

            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;
            this.ID_residente = ID_residente;
            this.divida = divida;
            this.ocupando = ocupando;
        }
    }
}
