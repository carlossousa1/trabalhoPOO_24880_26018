﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Residencia.Pessoa
{
    // Extrair classe externa
    using Conta;

    internal class Administrador : Conta, IAdministrador
    {
        public int ID_admin {  get; set; }

        public Administrador(int ID_admin, int ID_Conta, string nome, DateOnly dataNasc, string genero, string utilizador, string senha)
            : base(ID_Conta, nome, dataNasc, genero, utilizador, senha)
        {
            this.ID_Conta = ID_Conta;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;

            this.ID_admin = ID_admin;
        }
    }
}
