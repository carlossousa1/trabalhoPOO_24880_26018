﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

namespace Projeto_POO.Classes.Residencia.Pessoa
{
    // Extrair classe externa
    using Conta;

    internal class Funcionario : Conta, IFuncionario
    {
        public int ID_funcionario { get; set; }
        public int tipoServ { get; set; }

        public Funcionario(int ID_funcionario, int tipoServ, int ID_Conta, string nome, DateOnly dataNasc, string genero, string utilizador, string senha)
            : base(ID_Conta, nome, dataNasc, genero, utilizador, senha)
        {
            this.ID_Conta = ID_Conta;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;

            this.ID_funcionario = ID_funcionario;
            this.tipoServ = tipoServ;
        }
    }
}
