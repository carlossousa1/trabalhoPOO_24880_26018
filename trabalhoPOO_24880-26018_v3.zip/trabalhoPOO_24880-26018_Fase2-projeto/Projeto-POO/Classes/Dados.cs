﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018)
*/

using Projeto_POO.Classes.Conta;
using Projeto_POO.Classes.Residencia.Pessoa;
using Projeto_POO.Classes.Residencia.Quarto;
using Projeto_POO.Classes.Servico;

namespace Projeto_POO.Classes
{
    // Grupo que contém todas as listas com os dados armazenados do programa

    public static class Dados
    {
        public static List<IConta> ListaContas { get; set; } = new List<IConta>();
        public static List<IMorada> ListaMoradas { get; set; } = new List<IMorada>();
        public static List<ContaMorada> ListaContaMorada { get; set; } = new List<ContaMorada>();
        public static List<IContacto> ListaContactos { get; set; } = new List<IContacto>();
        public static List<ContaContacto> ListaContaContacto { get; set; } = new List<ContaContacto>();

        // ---

        public static List<IResidente> ListaResidentes { get; set; } = new List<IResidente>();
        public static List<ICandidato> ListaCandidatos { get; set; } = new List<ICandidato>();
        public static List<Candidatura> ListaCandidatura { get; set; } = new List<Candidatura>();
        public static List<IAdministrador> ListaAdministradores { get; set; } = new List<IAdministrador>();
        public static List<IFuncionario> ListaFuncionarios { get; set; } = new List<IFuncionario>();

        // ---

        public static List<IQuarto> ListaQuartos { get; set; } = new List<IQuarto>();
        public static List<QuartoResidente> ListaQuartoResidente { get; set; } = new List<QuartoResidente>();

        // ---

        public static List<Solicitacao> ListaSolicitacoes { get; set; } = new List<Solicitacao>();
    }
}
