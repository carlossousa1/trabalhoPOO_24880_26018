CREATE TABLE Conta (
  ID_Conta   int IDENTITY NOT NULL, 
  nome       char(30) NULL, 
  dataNasc   datetime NULL, 
  genero     char(1) NULL, 
  utilizador char(20) NULL, 
  senha      char(20) NULL, 
  PRIMARY KEY (ID_Conta));
CREATE TABLE Contacto (
  ID_contacto   int IDENTITY NOT NULL, 
  valor         char(30) NULL, 
  tipo_contacto char(30) NULL, 
  PRIMARY KEY (ID_contacto));
CREATE TABLE ContaContacto (
  ID_conta    int NOT NULL, 
  ID_contacto int NOT NULL);
CREATE TABLE Morada (
  ID_morada  int IDENTITY NOT NULL, 
  morada     char(30) NULL, 
  cod_postal char(30) NULL, 
  PRIMARY KEY (ID_morada));
CREATE TABLE ContaMorada (
  ID_conta  int NOT NULL, 
  ID_morada int NOT NULL);
CREATE TABLE Administrador (
  ID_admin   int IDENTITY NOT NULL, 
  ID_Conta   int NOT NULL, 
  nome       char(30) NULL, 
  dataNasc   datetime NULL, 
  genero     char(1) NULL, 
  utilizador char(20) NULL, 
  senha      char(20) NULL, 
  PRIMARY KEY (ID_admin));
CREATE TABLE Candidato (
  ID_candidato int IDENTITY NOT NULL, 
  estado       int NULL, 
  ID_Conta     int NOT NULL, 
  nome         char(30) NULL, 
  dataNasc     datetime NULL, 
  genero       char(1) NULL, 
  utilizador   char(20) NULL, 
  senha        char(20) NULL, 
  PRIMARY KEY (ID_candidato));
CREATE TABLE Candidatura (
  ID_candidatura  int IDENTITY NOT NULL, 
  ID_candidato    int NOT NULL, 
  dataCandidatura datetime NULL, 
  PRIMARY KEY (ID_candidatura));
CREATE TABLE Funcionario (
  ID_funcionario int IDENTITY NOT NULL, 
  tipoServ       int NULL, 
  ID_Conta       int NOT NULL, 
  nome           char(30) NULL, 
  dataNasc       datetime NULL, 
  genero         char(1) NULL, 
  utilizador     char(20) NULL, 
  senha          char(20) NULL, 
  PRIMARY KEY (ID_funcionario));
CREATE TABLE Residente (
  ID_residente int IDENTITY NOT NULL, 
  divida       int NULL, 
  ocupando     int NULL, 
  ID_Conta     int NOT NULL, 
  nome         char(30) NULL, 
  dataNasc     datetime NULL, 
  genero       char(1) NULL, 
  utilizador   char(20) NULL, 
  senha        char(10) NULL, 
  PRIMARY KEY (ID_residente));
CREATE TABLE Quarto (
  ID_quarto  int IDENTITY NOT NULL, 
  tipoQuarto int NULL, 
  lotacao    int NULL, 
  PRIMARY KEY (ID_quarto));
CREATE TABLE QuartoResidente (
  ID_residente int NOT NULL, 
  ID_quarto    int NOT NULL);
CREATE TABLE Pagamento (
  ID_Pagamento  int IDENTITY NOT NULL, 
  ID_Conta      int NOT NULL, 
  DataPagamento datetime NULL, 
  Valor         int NULL, 
  PRIMARY KEY (ID_Pagamento));
CREATE TABLE Solicitacao (
  ID_solicitacao  int IDENTITY NOT NULL, 
  tipoSolicitacao int NULL, 
  dataSolicitacao datetime NULL, 
  ID_Conta        int NOT NULL, 
  justificacao    char(30) NULL, 
  status          int NULL, 
  resposta        char(30) NULL, 
  PRIMARY KEY (ID_solicitacao));
CREATE TABLE PagamentoDivida (
  ID_PagamentoDivida  int IDENTITY NOT NULL, 
  ID_Conta            int NOT NULL, 
  DataPagamentoDivida datetime NULL, 
  Valor               int NULL, 
  PRIMARY KEY (ID_PagamentoDivida));
ALTER TABLE ContaContacto ADD CONSTRAINT FKContaConta688293 FOREIGN KEY (ID_conta) REFERENCES Conta (ID_Conta);
ALTER TABLE ContaContacto ADD CONSTRAINT FKContaConta602052 FOREIGN KEY (ID_contacto) REFERENCES Contacto (ID_contacto);
ALTER TABLE ContaMorada ADD CONSTRAINT FKContaMorad132007 FOREIGN KEY (ID_conta) REFERENCES Conta (ID_Conta);
ALTER TABLE ContaMorada ADD CONSTRAINT FKContaMorad489545 FOREIGN KEY (ID_morada) REFERENCES Morada (ID_morada);
ALTER TABLE Administrador ADD CONSTRAINT FKAdministra149797 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE Candidato ADD CONSTRAINT FKCandidato767400 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE Candidatura ADD CONSTRAINT FKCandidatur956076 FOREIGN KEY (ID_candidato) REFERENCES Candidato (ID_candidato);
ALTER TABLE Funcionario ADD CONSTRAINT FKFuncionari384620 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE Residente ADD CONSTRAINT FKResidente820166 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE QuartoResidente ADD CONSTRAINT FKQuartoResi708834 FOREIGN KEY (ID_residente) REFERENCES Residente (ID_residente);
ALTER TABLE QuartoResidente ADD CONSTRAINT FKQuartoResi996393 FOREIGN KEY (ID_quarto) REFERENCES Quarto (ID_quarto);
ALTER TABLE Pagamento ADD CONSTRAINT FKPagamento953874 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE Solicitacao ADD CONSTRAINT FKSolicitaca499562 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
ALTER TABLE PagamentoDivida ADD CONSTRAINT FKPagamentoD875983 FOREIGN KEY (ID_Conta) REFERENCES Conta (ID_Conta);
