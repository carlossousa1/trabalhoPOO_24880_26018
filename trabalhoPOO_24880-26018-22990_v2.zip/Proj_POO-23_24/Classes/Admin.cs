﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using Fase1.Classes.SubClasses;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Admin : Pessoa
    {
        public int ID_admin;

        public Admin(int ID_admin, int ID_pessoa, string nome, DateOnly dataNasc, char genero, string utilizador, string senha)
            : base(ID_pessoa, nome, dataNasc, genero, utilizador, senha)
        {
            // ----
            this.ID_Pessoa = ID_pessoa;
            
            // Informações da Pessoa
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;

            // Informações da Conta
            this.utilizador = utilizador;
            this.senha = senha;
            // ----

            // informacao exclusiva
            this.ID_admin = ID_admin;
        }
    }
}
