﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using Fase1.Classes.SubClasses;
using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Fase1.Classes
{
    internal class Residente : Pessoa
    {
        public int ID_residente { get; set; }
        public int ID_processo { get; set; }

        public Residente(int ID_residente, int ID_processo, int ID_pessoa, string nome, DateOnly dataNasc, char genero, string utilizador, string senha)
            : base(ID_pessoa, nome, dataNasc, genero, utilizador, senha)
        {
            // ----
            this.ID_Pessoa = ID_pessoa;

            // Informações da Pessoa
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;
            // ----

            // informacao exclusiva
            this.ID_residente = ID_residente;
            this.ID_processo = ID_processo;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarResidentes()
        {
            Console.WriteLine("ID Residente: {0}", ID_residente);
            Console.WriteLine("Conta Associada: {0}", ID_Pessoa);
            Console.WriteLine("ID Processo: {0}", ID_processo);
            Console.WriteLine("Nome: {0}", nome);
            Console.WriteLine("Data de Nascimento: {0}", dataNasc);
            Console.WriteLine("Genero: {0}", genero);
            Console.WriteLine("-----------");
        }


        // Método público para editar os dados
        public void EditarResidente(int ID_residente, int ID_processo, int ID_Pessoa, string nome, DateOnly dataNasc, char genero, string utilizador, string senha)
        {
            this.ID_Pessoa = ID_Pessoa;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;
            this.utilizador = utilizador;
            this.senha = senha;

            // informacao exclusiva
            this.ID_residente = ID_residente;
            this.ID_processo = ID_processo;

            Console.WriteLine("Dados do residente editados com sucesso!");
        }
    }
}
