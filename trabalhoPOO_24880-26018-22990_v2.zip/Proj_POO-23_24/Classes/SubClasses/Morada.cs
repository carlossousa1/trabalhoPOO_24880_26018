﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes.SubClasses
{
    internal class Morada
    {
        public int ID_morada;
        protected string morada;
        protected string cod_postal;
        // Lista de Contas que tem a morada
        public List<int> pessoa_lista;

        public Morada(int ID_morada, string morada, string cod_postal, List<int> pessoa_lista)
        {
            // informacao exclusiva
            this.ID_morada = ID_morada;
            this.morada = morada;
            this.cod_postal = cod_postal;
            this.pessoa_lista = pessoa_lista;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarMorada(bool check)
        {
            if (ID_morada != -1)
            {
                Console.WriteLine("ID Morada: {0}", ID_morada);
                Console.WriteLine("Morada: {0}", morada);
                Console.WriteLine("Código Postal: {0}", cod_postal);
                Console.WriteLine("Pessoas na Morada:");
                if (check == true)
                {
                    Console.WriteLine("-----------");
                    foreach (var ID in pessoa_lista)
                    {
                        Console.WriteLine($"Número: {ID}");
                    }
                }
            }
            else
            {
                Console.WriteLine("Vazio");
            }
        }
    }
}
