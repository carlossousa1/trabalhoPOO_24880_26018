﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes.SubClasses
{
    internal class Candidatura
    {
        public int ID_candidatura;
        protected int ID_candidato;
        protected DateOnly dataCandidatura;

        public Candidatura(int ID_candidatura, int ID_candidato, DateOnly dataCandidatura)
        {
            // informacao exclusiva
            this.ID_candidatura = ID_candidatura;
            this.ID_candidato = ID_candidato;
            this.dataCandidatura = dataCandidatura;

        }
    }
}
