﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes.SubClasses
{
    internal class Solicitacao
    {
        public int ID_solicitacao;
        public int tipoSolicitacao;
        public DateOnly dataSolicitacao; //protected
        public int ID_Pessoa;
        public string justificacao; //protected
        public bool status;
        public string resposta; //protected

        public Solicitacao(int ID_solicitacao, int tipoSolicitacao, DateOnly dataSolicitacao, int ID_Pessoa, string justificacao, bool status, string resposta)
        {
            // informacao exclusiva
            this.ID_solicitacao = ID_solicitacao;
            this.tipoSolicitacao = tipoSolicitacao;
            this.dataSolicitacao = dataSolicitacao;
            this.ID_Pessoa = ID_Pessoa;
            this.justificacao = justificacao;
            this.status = status;
            this.resposta = resposta;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarSolicitacoes(bool tipo)
        {
            if (status == true)
            {
                Console.WriteLine("ID Solicitacao: {0}", ID_Pessoa);
                Console.Write("Tipo Solicitacao: ");
                switch (tipoSolicitacao)
                {
                    case 1:
                        Console.WriteLine("Candidatura");
                        break;
                    case 2:
                        Console.WriteLine("Realocação Quarto");
                        break;
                    case 3:
                        Console.WriteLine("Reserva Quarto");
                        break;
                    default:
                        Console.WriteLine("Desconhecido");
                        break;

                }
                Console.WriteLine("Data Solicitação: {0}", dataSolicitacao);

                // Procurar pessoa na lista pelo id
                Pessoa PessoaListar = Program.listaPessoas.Find(r => r.ID_Pessoa.Equals(this.ID_Pessoa));
                if (PessoaListar != null)
                {
                    string nomePessoa = PessoaListar.PessoaNome(this.ID_Pessoa);
                    Console.WriteLine("Solicitante: {0} ({1})", nomePessoa, ID_Pessoa);
                }
                else
                {
                    Console.WriteLine("Solicitante: ??? ({0})", ID_Pessoa);
                }
                Console.WriteLine("-----------");
                // Não Admin
                if (tipo == true)
                {
                    Console.WriteLine("Justificação: {0}", justificacao);
                }
                // Admin
                else
                {
                    Console.WriteLine("Resposta: {0}", resposta);
                }
            }
        }

        public void SolicitacaoResposta(string resposta)
        {
            this.resposta = resposta;
        }

        public void SolicitacaoJustificacao(string justificacao)
        {
            this.justificacao = justificacao;
        }
    }
}
