﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes.SubClasses
{
    internal class Contacto
    {
        public int ID_contacto;
        protected string valor;
        protected string tipo_contacto;
        // Lista de Contas que tem o contacto
        public List<int> pessoa_lista;

        public Contacto(int ID_contacto, string valor, string tipo_contacto, List<int> pessoa_lista)
        {
            // informacao exclusiva
            this.ID_contacto = ID_contacto;
            this.valor = valor;
            this.tipo_contacto = tipo_contacto;
            this.pessoa_lista = pessoa_lista;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarContacto(bool check)
        {
            if (ID_contacto != -1)
            {
                Console.WriteLine("ID Contacto: {0}", ID_contacto);
                Console.WriteLine("Valor: {0}", valor);
                Console.WriteLine("Tipo Contacto: {0}", tipo_contacto);
                if (check == true)
                {
                    Console.WriteLine("-----------");
                    foreach (var ID in pessoa_lista)
                    {
                        Console.WriteLine($"Número: {ID}");
                    }
                }
            }
            else
            {
                Console.WriteLine("Vazio");
            }
        }
    }
}
