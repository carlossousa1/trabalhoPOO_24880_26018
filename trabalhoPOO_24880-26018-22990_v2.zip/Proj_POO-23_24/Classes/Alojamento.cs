﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using Fase1.Classes.SubClasses;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Alojamento
    {
        public int ID_quarto { get; set; }
        protected string tipoQuarto { get; set; }
        protected int lotacao { get; set; }

        // Lista de residentes no quarto, por ID_Residente
        protected List<int> listaResidID = new List<int>();

        public Alojamento(int ID_quarto, string tipoQuarto, int lotacao, List<int> listaResidID)
        {
            // informacao exclusiva
            this.ID_quarto = ID_quarto;
            this.tipoQuarto = tipoQuarto;
            this.lotacao = lotacao;
            this.listaResidID = listaResidID;
        }
    }
}
