﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using Fase1.Classes.SubClasses;
using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace Fase1.Classes
{
    internal class Pessoa
    {
        public int ID_Pessoa { get; set; }

        // Informações da Pessoa
        protected string nome { get; set; }
        protected DateOnly dataNasc { get; set; }
        protected char genero { get; set; }

        // Informações da Conta
        public string utilizador { get; set; }
        public string senha { get; set; }

        public Pessoa(int ID_pessoa, string nome, DateOnly dataNasc, char genero, string utilizador, string senha)
        {
            this.ID_Pessoa = ID_pessoa;

            // Informações da Pessoa
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;

            // Informações da Conta
            this.utilizador = utilizador;
            this.senha = senha;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarPessoas()
        {
            Console.WriteLine("ID Conta: {0}", ID_Pessoa);
            Console.WriteLine("Nome: {0}", nome);
            Console.WriteLine("Data Nascimento: {0}", dataNasc);
            Console.WriteLine("Gênero: {0}", genero);
            Console.WriteLine("Utilizador: {0}", utilizador);
            Console.WriteLine("-----------");
            Console.WriteLine("Grupos Associados:");
            // Verificar Residentes
            foreach (Residente residente in Program.listaResidentes)
            {
                if (residente.ID_Pessoa == this.ID_Pessoa)
                {
                    Console.WriteLine("ID Residente: {0}", residente.ID_residente);
                }
            }
            // Verificar Candidatos
            foreach (Candidato candidato in Program.listaCandidatos)
            {
                if (candidato.ID_Pessoa == this.ID_Pessoa && candidato.CandidatoEstado(this.ID_Pessoa) == true)
                {
                    Console.WriteLine("ID Candidato: {0}", candidato.ID_cantidato);
                }
            }
            // Verificar Funcionários
            foreach (Funcionario funcionario in Program.listaFuncionarios)
            {
                if (funcionario.ID_Pessoa == this.ID_Pessoa)
                {
                    Console.WriteLine("ID Funcionário: {0}", funcionario.ID_funcionario);
                }
            }
            // Verificar Administradores
            foreach (Admin admin in Program.listaAdmin)
            {
                if (admin.ID_Pessoa == this.ID_Pessoa)
                {
                    Console.WriteLine("ID Administrador: {0}", admin.ID_admin);
                }
            }
        }

        // Método público para editar os dados
        public void EditarPessoa(int ID_Pessoa, string nome, DateOnly dataNasc, char genero, string utilizador, string senha)
        {
            // informacao exclusiva
            this.ID_Pessoa = ID_Pessoa;
            this.nome = nome;
            this.dataNasc = dataNasc;
            this.genero = genero;
            this.utilizador = utilizador;
            this.senha = senha;

            Console.WriteLine("Dados da conta editados com sucesso!");
        }

        // Método para atualizar subgrupos com a conta
        public void AtualizarSubGrupo(int ID)
        {
            // Atualizar residentes
            Residente residenteEncontrar = Program.listaResidentes.Find(r => r.ID_Pessoa.Equals(ID));
            if (residenteEncontrar != null)
            {
                residenteEncontrar.EditarResidente(residenteEncontrar.ID_residente, residenteEncontrar.ID_processo, this.ID_Pessoa,
                    this.nome, this.dataNasc, this.genero, this.utilizador, this.senha);
            }
        }

        // Método para remover subgrupos com a conta
        public void RemoverSubGrupo(int ID)
        {
            // Remover residentes
            Residente residenteRemover = Program.listaResidentes.Find(r => r.ID_Pessoa.Equals(ID));
            if (residenteRemover != null)
            {
                Program.listaResidentes.Remove(residenteRemover);
            }
        }

        // Verificar se o ID correspondente existe na lista
        bool PessoaCheck(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if(pessoa.ID_Pessoa == ID)
                {
                    return true;
                }
            }
            return false;
        }

        public string PessoaNome(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if (pessoa.ID_Pessoa == ID)
                {
                    return pessoa.nome;
                }
            }
            return null;
        }

        public DateOnly PessoaDataNasc(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if (pessoa.ID_Pessoa == ID)
                {
                    return pessoa.dataNasc;
                }
            }
            return new DateOnly(1,1,1);
        }

        public char PessoaGenero(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if (pessoa.ID_Pessoa == ID)
                {
                    return pessoa.genero;
                }
            }
            return 'o';
        }

        public string PessoaUtilizador(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if (pessoa.ID_Pessoa == ID)
                {
                    return pessoa.utilizador;
                }
            }
            return null;
        }

        public string PessoaSenha(int ID)
        {
            foreach (Pessoa pessoa in Program.listaPessoas)
            {
                if (pessoa.ID_Pessoa == ID)
                {
                    return pessoa.senha;
                }
            }
            return null;
        }

    }
}
