﻿/*
 * Projeto POO - Software para a Gestão de uma Residência Universitária: v1
 * Curso LESI-PL, Escola de Tecnologia : Instituto Politécnico do Cávado e do Ave
 * Discentes: Carlos Sousa (24880), Pedro Gonçalves (26018), Kizzy Barreto (22990)
*/

using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using Fase1.Classes;
using Fase1.Classes.SubClasses;

class Program
{
    // Listas
    public static List<Pessoa> listaPessoas = new List<Pessoa>();
    
    public static List<Morada> listaMoradas = new List<Morada>();
    public static List<Contacto> listaContactos = new List<Contacto>();
    public static List<Solicitacao> listaSolicitacoes = new List<Solicitacao>();

    public static List<Residente> listaResidentes = new List<Residente>();
    public static List<Candidato> listaCandidatos = new List<Candidato>();
    public static List<Funcionario> listaFuncionarios = new List<Funcionario>();
    public static List<Admin> listaAdmin = new List<Admin>();

    public static List<Alojamento> listaQuartos = new List<Alojamento>();

    // =================================== MENUS ===================================

    static void Main()
    {
        DateOnly dataNascf = new DateOnly(1, 1, 1);
        listaSolicitacoes.Add(new Solicitacao(1, 2, dataNascf, 1, "sim", true, "não"));

        int modo = 1;
        while (true)
        {
            exit_loop:
            // 1 - Modo Admin
            // 2 - Modo Utilizador
            // 3 - Modo Candidato
            // 4 - Modo Funcionário
            while (true)
            {
                Console.Clear();
                Console.Write("(0=sair)\nModo: ");
                modo = int.Parse(Console.ReadLine());

                if (modo == 1 || modo == 2 || modo == 3 || modo == 4)
                {
                    break;
                }
                else if (modo == 0)
                {
                    Environment.Exit(0);
                }
            }

            #region Menu Admin
            if (modo == 1)
            {
                
                int admin_modo = 1;

                while (true)
                {
                    #region 1=contas
                    if (admin_modo == 1)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("Alvo de Edição: Contas");
                        Console.WriteLine("1. Listar Contas");
                        Console.WriteLine("2. Adicionar Conta");
                        Console.WriteLine("3. Editar Conta");
                        Console.WriteLine("4. Remover Conta");
                        Console.WriteLine("9. Trocar Edição");
                        Console.WriteLine("0. Sair");
                        Console.Write("Escolha uma opção: ");

                        if (int.TryParse(Console.ReadLine(), out int opcao))
                        {
                            switch (opcao)
                            {
                                case 1:
                                    ListarContas();
                                    break;

                                case 2:
                                    AdicionarConta();
                                    break;

                                case 3:
                                    EditarConta();
                                    break;

                                case 4:
                                    RemoverConta();
                                    break;

                                case 9:
                                    while (true)
                                    {
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6) break;
                                    }

                                    break;

                                case 0:
                                    goto exit_loop;// Sair do programa
                                    break;

                                default:
                                    Console.WriteLine("Opção inválida. Tente novamente.");
                                    break;
                            }
                        }
                    }
                    #endregion

                    #region 2=residentes
                    if (admin_modo == 2)
                    {

                        Console.WriteLine("\n");
                        Console.WriteLine("Alvo de Edição: Residentes");
                        Console.WriteLine("1. Listar Residentes");
                        Console.WriteLine("2. Adicionar Residente");
                        Console.WriteLine("3. Editar Residente");
                        Console.WriteLine("4. Remover Residente");
                        Console.WriteLine("9. Trocar Edição");
                        Console.WriteLine("0. Sair");
                        Console.Write("Escolha uma opção: ");

                        if (int.TryParse(Console.ReadLine(), out int opcao))
                        {
                            switch (opcao)
                            {
                                case 1:
                                    ListarResidentes();
                                    break;

                                case 2:
                                    AdicionarResidente();
                                    break;

                                case 3:
                                    EditarResidente();
                                    break;

                                case 4:
                                    RemoverResidente();
                                    break;

                                case 9:
                                    while (true)
                                    {
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6) break;
                                    }

                                    break;

                                case 0:
                                    Environment.Exit(0); // Sair do programa
                                    break;

                                default:
                                    Console.WriteLine("Opção inválida. Tente novamente.");
                                    break;
                            }
                        }
                        else
                        {
                            Console.WriteLine("Entrada inválida. Tente novamente.");
                        }
                    }

                    #endregion

                    #region 3=candidato
                    #endregion

                    #region 4=funcionario
                    #endregion

                    #region 5=alojamento
                    #endregion

                    #region 6=solicitacao
                    if (admin_modo == 6)
                    {
                        Console.WriteLine("\n");
                        Console.WriteLine("Alvo de Edição: Solicitações");
                        Console.WriteLine("1. Listar Solicitações");
                        Console.WriteLine("2. Listar Solicitação P/Pessoa");
                        Console.WriteLine("3. Atualizar Solicitação");
                        Console.WriteLine("9. Trocar Edição");
                        Console.WriteLine("0. Sair");
                        Console.Write("Escolha uma opção: ");

                        if (int.TryParse(Console.ReadLine(), out int opcao))
                        {
                            switch (opcao)
                            {
                                case 1:
                                    ListarSolicitacoes();
                                    break;

                                case 2:
                                    ListarSolicitacoesPessoa();
                                    break;

                                case 3:
                                    AtualizarSolicitacao();
                                    break;

                                case 9:
                                    while (true)
                                    {
                                        Console.Write("Modo: ");
                                        admin_modo = int.Parse(Console.ReadLine());
                                        if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3 || admin_modo == 4
                                            || admin_modo == 5 || admin_modo == 6) break;
                                    }

                                    break;

                                case 0:
                                    goto exit_loop;// Sair do programa
                                    break;

                                default:
                                    Console.WriteLine("Opção inválida. Tente novamente.");
                                    break;
                            }
                        }
                    }
                    #endregion
                }
            }
            #endregion
        }
    }

    // =================================== FUNÇÕES ===================================

    #region ADMIN gerir conta
    static void ListarContas()
    {
        Console.WriteLine("\nLista de Contas:");

        Console.WriteLine("-----------");
        foreach (Pessoa conta in listaPessoas)
        {
            conta.ListarPessoas();

            Console.WriteLine("-----------\n");
        }
    }

    static void AdicionarConta()
    {
        Console.WriteLine("\nAdicionar Conta:");

        // Solicitar ID conta
        int id_pessoa = -1;
        while (id_pessoa == -1 || listaResidentes.Any(r => r.ID_Pessoa == id_pessoa))
        {
            Console.Write("ID Conta: ");
            id_pessoa = int.Parse(Console.ReadLine());
        }

        // Solicitar dados a conta
        Console.Write("Nome: ");
        string nome = Console.ReadLine();

        Console.Write("Data Nascimento (ano, mês, dia): ");
        DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

        Console.Write("Gênero: ");
        char genero = char.Parse(Console.ReadLine());

        Console.Write("Utilizador: ");
        string utilizador = Console.ReadLine();

        Console.Write("Senha: ");
        string senha = Console.ReadLine();

        //Residente novoResidente = new Residente(id_residente, id_processo, id_pessoa, nome, dataNasc, new List<Morada> { morada }, genero, new List<Contacto> { contacto }, "", "");
        Pessoa novaPessoa = new Pessoa(id_pessoa, nome, dataNasc, genero, utilizador, senha);

        // Adicionar à lista de residentes
        listaPessoas.Add(novaPessoa);

        Console.WriteLine("Conta adicionada com sucesso!");
    }

    static void EditarConta()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Editar Conta:");

        // Solicitar ao usuário o ID do residente a ser editado
        Console.Write("ID Conta: ");
        int ID_Pessoa_Find = int.Parse(Console.ReadLine());

        // Procurar conta na lista pelo id
        Pessoa pessoaParaEditar = listaPessoas.Find(r => r.ID_Pessoa.Equals(ID_Pessoa_Find));

        if (pessoaParaEditar != null)
        {
            // Guardar ID antigo
            int id_pessoa_old = pessoaParaEditar.ID_Pessoa;
            // ID da conta
            int id_pessoa = -1;
            while (id_pessoa == -1 || listaPessoas.Any(r => r.ID_Pessoa == id_pessoa))
            {
                Console.Write("ID Conta: ");
                id_pessoa = int.Parse(Console.ReadLine());
                if (id_pessoa == pessoaParaEditar.ID_Pessoa) break;
            }

            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Data Nascimento: \n");
            DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            Console.Write("Gênero: ");
            char genero = char.Parse(Console.ReadLine());

            Console.Write("Utilizador: ");
            string utilizador = Console.ReadLine();

            Console.Write("Senha: ");
            string senha = Console.ReadLine();

            pessoaParaEditar.EditarPessoa(id_pessoa, nome, dataNasc, genero, utilizador, senha);

            char resposta = 'o';
            while (true)
            {
                Console.WriteLine("\nAtualizar subgrupos? (s/n)");
                resposta = char.ToLower(char.Parse(Console.ReadLine()));

                if (resposta == 's' || resposta == 'n')
                {
                    break;
                }
            }

            if (resposta == 's')
            {
                // Procurar conta atualizada na lista pelo novo id
                Pessoa pessoaParaEditarNovo = listaPessoas.Find(r => r.ID_Pessoa.Equals(id_pessoa));

                if (pessoaParaEditarNovo != null)
                {
                    pessoaParaEditarNovo.AtualizarSubGrupo(id_pessoa_old);
                    Console.WriteLine("Subgrupos alterados com sucesso!");
                }
                else
                {
                    Console.WriteLine("Erro ao atualizar os dados!");
                }
            }
        }
        else
        {
            Console.WriteLine("Conta não encontrada!");
        }
        Console.WriteLine("-----------");
    }

    static void RemoverConta()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Remover Conta:");

        // Solicitar ao usuário o ID da conta a ser removida
        Console.Write("ID Conta: ");
        int ID_Pessoa_Find = int.Parse(Console.ReadLine());

        // Procurar residente na lista pelo id
        Pessoa pessoaParaRemover = listaPessoas.Find(r => r.ID_Pessoa.Equals(ID_Pessoa_Find));

        if (pessoaParaRemover != null)
        {
            // Remover residente da lista
            listaPessoas.Remove(pessoaParaRemover);

            Console.WriteLine("Conta removida com sucesso!");

            char resposta = 'o';
            while (true)
            {
                Console.WriteLine("\nRemover subgrupos? (s/n)");
                resposta = char.ToLower(char.Parse(Console.ReadLine()));

                if (resposta == 's' || resposta == 'n')
                {
                    break;
                }

            }

            if (resposta == 's')
            {

                pessoaParaRemover.RemoverSubGrupo(ID_Pessoa_Find);
                Console.WriteLine("Subgrupos removidos com sucesso!");
            }
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
        Console.WriteLine("-----------");
    }

    #endregion

    #region ADMIN gerir residente
    static void ListarResidentes()
    {
        Console.WriteLine("\nLista de Residentes:");

        Console.WriteLine("-----------");
        foreach (Residente residente in listaResidentes)
        {
            residente.ListarResidentes();

            Console.WriteLine("Morada(s):");
            foreach (Morada morada in listaMoradas)
            {
                foreach (var ID in morada.pessoa_lista)
                {
                    if (residente.ID_Pessoa == ID)
                    {
                        morada.ListarMorada(false);
                    } 
                }
            }

            Console.WriteLine("-----------");

            Console.WriteLine("Contacto(s):");
            foreach (Contacto contacto in listaContactos)
            {
                foreach (var ID in contacto.pessoa_lista)
                {
                    if (residente.ID_Pessoa == ID)
                    {
                        contacto.ListarContacto(false);
                    }
                }
            }
            Console.WriteLine("-----------\n");
        }
    }

    static void AdicionarResidente()
    {
        Console.WriteLine("\nAdicionar Residente:");

        // Solicitar ID conta associada ao utilizador
        int id_pessoa = -1;
        while (id_pessoa == -1 || listaResidentes.Any(r => r.ID_Pessoa == id_pessoa))
        {
            Console.Write("ID Conta: ");
            id_pessoa = int.Parse(Console.ReadLine());
        }
        Pessoa pessoaLista = listaPessoas.Find(r => r.ID_Pessoa.Equals(id_pessoa));
        if (pessoaLista != null)
        {
            // ID do utilizador
            int id_residente = -1;
            while (id_residente == -1 || listaResidentes.Any(r => r.ID_residente == id_residente))
            {
                Console.Write("ID Residente: ");
                id_residente = int.Parse(Console.ReadLine());
            }

            // Solicitar ID processo ao utilizador
            int id_processo = -1;
            while (id_processo == -1 || listaResidentes.Any(r => r.ID_processo == id_processo))
            {
                Console.Write("ID Processo: ");
                id_processo = int.Parse(Console.ReadLine());
            }

            // herdar valores da conta
            string nome = pessoaLista.PessoaNome(id_pessoa);
            DateOnly dataNasc = pessoaLista.PessoaDataNasc(id_pessoa);
            char genero = pessoaLista.PessoaGenero(id_pessoa);
            string utilizador = pessoaLista.PessoaUtilizador(id_pessoa);
            string senha = pessoaLista.PessoaSenha(id_pessoa);

            //Residente novoResidente = new Residente(id_residente, id_processo, id_pessoa, nome, dataNasc, new List<Morada> { morada }, genero, new List<Contacto> { contacto }, "", "");
            Residente novoResidente = new Residente(id_residente, id_processo, id_pessoa, nome, dataNasc, genero, utilizador, senha);

            // Adicionar à lista de residentes
            listaResidentes.Add(novoResidente);

            Console.WriteLine("Residente adicionado com sucesso!");
        }
        else
        {
            Console.WriteLine("Conta não existe!");
        }
        
    }

    static void EditarResidente()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Editar Residente:");

        // Solicitar ao usuário o ID do residente a ser editado
        Console.Write("ID Residente: ");
        int ID_Residente_Find = int.Parse(Console.ReadLine());

        // Procurar residente na lista pelo id
        Residente residenteParaEditar = listaResidentes.Find(r => r.ID_residente.Equals(ID_Residente_Find));

        if (residenteParaEditar != null)
        {
            // ID do utilizador
            int id_residente = -1;
            while (id_residente == -1 || listaResidentes.Any(r => r.ID_residente == id_residente))
            {
                Console.Write("ID Residente: ");
                id_residente = int.Parse(Console.ReadLine());
                if (id_residente == residenteParaEditar.ID_residente) break;
            }

            // ID do processo
            int id_processo = -1;
            while (id_processo == -1 || listaResidentes.Any(r => r.ID_processo == id_processo))
            {
                Console.Write("ID Processo: ");
                id_processo = int.Parse(Console.ReadLine());
                if (id_processo == residenteParaEditar.ID_processo) break;
            }

            // ID da conta
            int id_pessoa = -1;
            while (id_pessoa == -1 || listaResidentes.Any(r => r.ID_Pessoa == id_pessoa))
            {
                Console.Write("ID Conta: ");
                id_pessoa = int.Parse(Console.ReadLine());
                if (id_pessoa == residenteParaEditar.ID_Pessoa) break;
            }
            Pessoa pessoaLista = listaPessoas.Find(r => r.ID_Pessoa.Equals(id_pessoa));
            if (pessoaLista != null)
            {
                // herdar valores da conta
                string nome = pessoaLista.PessoaNome(id_pessoa);
                DateOnly dataNasc = pessoaLista.PessoaDataNasc(id_pessoa);
                char genero = pessoaLista.PessoaGenero(id_pessoa);
                string utilizador = pessoaLista.PessoaUtilizador(id_pessoa);
                string senha = pessoaLista.PessoaSenha(id_pessoa);

                residenteParaEditar.EditarResidente(id_residente, id_processo, id_pessoa, nome, dataNasc, genero, utilizador, senha);

                Console.WriteLine("Residente alterado!");
            }
            else
            {
                Console.WriteLine("Conta não existe!");
            }
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
        Console.WriteLine("-----------");
    }

    static void RemoverResidente()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Remover Residente:");

        // Solicitar ao usuário o ID do residente a ser removido
        Console.Write("ID Residente: ");
        int ID_Residente_Find = int.Parse(Console.ReadLine());

        // Procurar residente na lista pelo id
        Residente residenteParaRemover = listaResidentes.Find(r => r.ID_residente.Equals(ID_Residente_Find));

        if (residenteParaRemover != null)
        {
            // Remover residente da lista
            listaResidentes.Remove(residenteParaRemover);

            Console.WriteLine("Residente removido com sucesso!");
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
        Console.WriteLine("-----------");
    }
    #endregion

    #region ADMIN gerir candidato
    #endregion

    #region ADMIN gerir quarto
    #endregion

    #region ADMIN gerir funcionario
    #endregion

    #region ADMIN gerir solicitacoes
    static void ListarSolicitacoes()
    {
        Console.WriteLine("\nSolicitações Pendentes:");

        Console.WriteLine("-----------");
        foreach (Solicitacao solicitacao in listaSolicitacoes)
        {
            if (solicitacao.status == true)
            {
                solicitacao.ListarSolicitacoes(true);
                Console.WriteLine("-----------\n");
            }
        }
    }

    static void ListarSolicitacoesPessoa()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Solicitação de uma única pessoa:");

        // Solicitar ao usuário o ID da pessoa
        Console.Write("ID da conta: ");
        int ID_Conta_Find = int.Parse(Console.ReadLine());

        // Procurar solicitacao na lista pelo id
        Solicitacao solicitacaoParaListar = listaSolicitacoes.Find(r => r.ID_solicitacao.Equals(ID_Conta_Find));

        if (solicitacaoParaListar != null)
        {
            // Procurar pessoa na lista pelo id
            Pessoa PessoaListar = listaPessoas.Find(r => r.ID_Pessoa.Equals(ID_Conta_Find));
            Console.WriteLine("\n\n-----------");
            if (PessoaListar != null)
            {
                Console.WriteLine("Solicitações Pendentes de {0}:", PessoaListar.PessoaNome(ID_Conta_Find));
            }
            else
            {
                Console.WriteLine("Solicitações Pendentes de ???:");
            }
            Console.WriteLine("-----------");
            foreach (Solicitacao solicitacao in listaSolicitacoes)
            {
                if (solicitacao.status == true && solicitacao.ID_Pessoa == ID_Conta_Find)
                {
                    solicitacao.ListarSolicitacoes(true);
                    Console.WriteLine("-----------\n");
                }
            }
        }
        else
        {
            Console.WriteLine("Conta não encontrada!");
        }
        Console.WriteLine("-----------");
    }

    static void AtualizarSolicitacao()
    {
        Console.WriteLine("\n-----------");
        Console.WriteLine("Atualizar Solicitação:");

        // Solicitar ao usuário o ID da solicitacao a ser atualizada
        Console.Write("ID da Solicitação a ser atualizada: ");
        int ID_Solicitacao_Find = int.Parse(Console.ReadLine());

        // Procurar residente na lista pelo id
        Solicitacao solicitacaoParaEditar = listaSolicitacoes.Find(r => r.ID_solicitacao.Equals(ID_Solicitacao_Find));

        if (solicitacaoParaEditar != null)
        {
            if (solicitacaoParaEditar.status == true)
            {
                Console.WriteLine("-----------");
                solicitacaoParaEditar.ListarSolicitacoes(true);
                Console.WriteLine("-----------\n");

                char resposta = 'o';
                while (true)
                {
                    Console.WriteLine("Validar Solicitação? (s/n)");
                    resposta = char.ToLower(char.Parse(Console.ReadLine()));

                    if (resposta == 's' || resposta == 'n')
                    {
                        break;
                    }
                }

                Console.WriteLine("Resposta:");
                string retorno = Console.ReadLine();
                solicitacaoParaEditar.SolicitacaoResposta(retorno);

                // Validou
                if (resposta == 's')
                {
                    solicitacaoParaEditar.status = false;

                    // Efetuar Pedido
                    switch (solicitacaoParaEditar.tipoSolicitacao)
                    {
                        case 2: // realocação quarto
                            
                            break;

                        case 3: // reserva quarto

                            break;

                        default:
                            Console.WriteLine("Tipo não existente!");
                            break;
                    }

                }
                // Rejeitou
                else
                {
                    solicitacaoParaEditar.status = false;
                }

                //residenteParaEditar.EditarResidente(id_residente, id_processo, id_conta, nome, dataNasc, genero);
            }
        }
        else
        {
            Console.WriteLine("Solicitacão não encontrada!");
        }
        Console.WriteLine("-----------");
    }

    #endregion

    #region RESIDENTE uso serviços
    #endregion
}
