﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Funcionario : Pessoa
    {
        protected string TipoServ { get; set; }
        public Funcionario(string nome, DateOnly dataNasc, string morada, string genero, int contacto, string tipoServ, string utilizador, string senha) : base(nome, dataNasc, morada, genero, contacto, utilizador, senha)
        {
            Nome = nome;
            DataNasc = dataNasc;
            Morada = morada;
            Genero = genero;
            Contacto = contacto;
            TipoServ = tipoServ;

            Utilizador = utilizador;
            Senha = senha;
        }
    }
}
