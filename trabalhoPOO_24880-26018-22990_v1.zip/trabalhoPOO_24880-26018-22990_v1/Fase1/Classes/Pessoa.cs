﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Pessoa
    {
        // Informações da Pessoa
        protected string Nome { get; set; }
        protected DateOnly DataNasc { get; set; }
        protected string Morada { get; set; }
        protected string Genero { get; set; }
        protected int Contacto { get; set; }

        // Informações da Conta
        public string Utilizador { get; set; }
        public string Senha { get; set; }

        public Pessoa(string nome, DateOnly dataNasc, string morada, string genero, int contacto, string utilizador, string senha)
        {
            Nome = nome;
            DataNasc = dataNasc;
            Morada = morada;
            Genero = genero;
            Contacto = contacto;

            Utilizador = utilizador;
            Senha = senha;
        }
    }
}
