﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Alojamento
    {
        public int Id { get; set; }
        protected string TipoQuarto { get; set; }

        public Alojamento(int id, string tipoQuarto)
        {
            Id = id;
            TipoQuarto = tipoQuarto;
        }


        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarQuartos()
        {
            Console.WriteLine("Id: {0}", Id);
            Console.WriteLine("Tipo: {0}", TipoQuarto);

        }

        // Método público para editar os dados
        public void EditarDadosQuartos(int id, string tipoQuarto)
        {
            // informacao exclusiva
            TipoQuarto = tipoQuarto;

            Console.WriteLine("Dados do alojamento editados com sucesso!");
        }
    }
}
