﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace Fase1.Classes
{
    internal class Residente : Pessoa
    {
        protected bool Estado { get; set; }
        protected int QuartoId { get; set; }

        public Residente(string nome, DateOnly dataNasc, string morada, string genero, int contacto, string utilizador, string senha, bool estado, int quartoid) : base(nome, dataNasc, morada, genero, contacto, utilizador, senha)
        {
            Nome = nome;
            DataNasc = dataNasc;
            Morada = morada;
            Genero = genero;
            Contacto = contacto;

            Utilizador = utilizador;
            Senha = senha;

            // informacao exclusiva
            Estado = estado;
            QuartoId = quartoid;
        }

        // =================================== FUNÇÕES ===================================

        // Método público para mostrar as informações gerais
        public void ListarResidentes()
        {
            Console.WriteLine("Nome: {0}", Nome);
            Console.WriteLine("Data de Nascimento: {0}", DataNasc);
            Console.WriteLine("Morada: {0}", Morada);
            Console.WriteLine("Genero: {0}", Genero);
            Console.WriteLine("Contacto: {0}", Contacto);
            Console.WriteLine("Utilizador: {0}", Utilizador);
            Console.WriteLine("Estado: {0}", Estado);
            if (QuartoId != 0)
            {
                Console.WriteLine("Quarto: {0}", QuartoId);
            }
            else
            {
                Console.WriteLine("Quarto: Nenhum");
            }
            
        }

        // Método público para editar os dados
        public void EditarDados(string nome, DateOnly dataNasc, string morada, string genero, int contacto, string senha, bool estado, int quartoid)
        {
            Nome = nome;
            DataNasc = dataNasc;
            Morada = morada;
            Genero = genero;
            Contacto = contacto;

            Senha = senha;

            // informacao exclusiva
            Estado = estado;
            QuartoId = quartoid;

            Console.WriteLine("Dados do residente editados com sucesso!");
        }
    }
}
