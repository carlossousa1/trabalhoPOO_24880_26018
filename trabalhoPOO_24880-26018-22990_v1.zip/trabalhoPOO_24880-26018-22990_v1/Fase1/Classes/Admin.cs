﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fase1.Classes
{
    internal class Admin : Pessoa
    {
        public Admin(string nome, DateOnly dataNasc, string morada, string genero, int contacto, string utilizador, string senha) : base(nome, dataNasc, morada, genero, contacto, utilizador, senha)
        {
            Nome = nome;
            DataNasc = dataNasc;
            Morada = morada;
            Genero = genero;
            Contacto = contacto;

            Utilizador = utilizador;
            Senha = senha;
        }
    }
}
