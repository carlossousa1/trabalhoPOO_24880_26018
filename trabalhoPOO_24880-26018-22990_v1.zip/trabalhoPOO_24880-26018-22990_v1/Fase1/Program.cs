﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using Fase1.Classes;

class Program
{
    // Listas
    static List<Residente> listaResidentes = new List<Residente>();
    static List<Candidato> listaCandidatos = new List<Candidato>();
    static List<Alojamento> listaQuartos = new List<Alojamento>();

    // =================================== MENUS ===================================

    static void Main()
    {
        int modo = 1;
        while (true)
        {
            Console.Write("Modo: ");
            modo = int.Parse(Console.ReadLine());
            if (modo == 1 || modo == 2 || modo == 3) break;
        }

        #region Menu Admin
        if (modo == 1)
        {
            int admin_modo = 1;

            while (true)
            {
                #region 1=residentes
                if (admin_modo == 1)
                {

                    Console.WriteLine("\n");
                    Console.WriteLine("Alvo de Edição: Residentes");
                    Console.WriteLine("1. Listar Residentes");
                    Console.WriteLine("2. Adicionar Residente");
                    Console.WriteLine("3. Editar Residente");
                    Console.WriteLine("4. Remover Residente");
                    Console.WriteLine("9. Trocar Edição");
                    Console.WriteLine("0. Sair");
                    Console.Write("Escolha uma opção: ");

                    if (int.TryParse(Console.ReadLine(), out int opcao))
                    {
                        switch (opcao)
                        {
                            case 1:
                                ListarResidentes();
                                break;

                            case 2:
                                AdicionarResidente();
                                break;

                            case 3:
                                EditarResidente();
                                break;

                            case 4:
                                RemoverResidente();
                                break;

                            case 9:
                                while (true)
                                {
                                    Console.Write("Modo: ");
                                    admin_modo = int.Parse(Console.ReadLine());
                                    if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3) break;
                                }

                                break;

                            case 0:
                                Environment.Exit(0); // Sair do programa
                                break;

                            default:
                                Console.WriteLine("Opção inválida. Tente novamente.");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida. Tente novamente.");
                    }
                }

                #endregion

                #region 2=candidatos
                if (admin_modo == 2)
                {

                    Console.WriteLine("\n");
                    Console.WriteLine("Alvo de Edição: Candidatos");
                    Console.WriteLine("1. Listar Candidatos");
                    Console.WriteLine("2. Adicionar Candidato");
                    Console.WriteLine("3. Editar Candidato");
                    Console.WriteLine("4. Remover Candidato");
                    Console.WriteLine("9. Trocar Edição");
                    Console.WriteLine("0. Sair");
                    Console.Write("Escolha uma opção: ");

                    if (int.TryParse(Console.ReadLine(), out int opcao))
                    {
                        switch (opcao)
                        {
                            case 1:
                                ListarCandidatos();
                                break;

                            case 2:
                                AdicionarCandidato();
                                break;

                            case 3:
                                EditarCandidato();
                                break;

                            case 4:
                                RemoverCandidato();
                                break;

                            case 9:
                                while (true)
                                {
                                    Console.Write("Modo: ");
                                    admin_modo = int.Parse(Console.ReadLine());
                                    if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3) break;
                                }

                                break;

                            case 0:
                                Environment.Exit(0); // Sair do programa
                                break;

                            default:
                                Console.WriteLine("Opção inválida. Tente novamente.");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida. Tente novamente.");
                    }
                }

                #endregion

                #region 3=quartos
                if (admin_modo == 3)
                {

                    Console.WriteLine("\n");
                    Console.WriteLine("Alvo de Edição: Quartos");
                    Console.WriteLine("1. Listar Quartos");
                    Console.WriteLine("2. Adicionar Quarto");
                    Console.WriteLine("3. Editar Quarto");
                    Console.WriteLine("4. Remover Quarto");
                    Console.WriteLine("9. Trocar Edição");
                    Console.WriteLine("0. Sair");
                    Console.Write("Escolha uma opção: ");

                    if (int.TryParse(Console.ReadLine(), out int opcao))
                    {
                        switch (opcao)
                        {
                            case 1:
                                ListarQuartos();
                                break;

                            case 2:
                                AdicionarQuarto();
                                break;

                            case 3:
                                EditarQuarto();
                                break;

                            case 4:
                                RemoverQuarto();
                                break;

                            case 9:
                                while (true)
                                {
                                    Console.Write("Modo: ");
                                    admin_modo = int.Parse(Console.ReadLine());
                                    if (admin_modo == 1 || admin_modo == 2 || admin_modo == 3) break;
                                }

                                break;

                            case 0:
                                Environment.Exit(0); // Sair do programa
                                break;

                            default:
                                Console.WriteLine("Opção inválida. Tente novamente.");
                                break;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Entrada inválida. Tente novamente.");
                    }
                }

                #endregion
            }
        }
        #endregion

        #region Menu Utilizador
        if (modo == 2)
        {

            Console.WriteLine("\n");
            Console.WriteLine("1. Solicitar Serviços");
            //Console.WriteLine("2. Ver Perfil");
            Console.WriteLine("0. Sair");
            Console.Write("Escolha uma opção: ");

            if (int.TryParse(Console.ReadLine(), out int opcao))
            {
                switch (opcao)
                {
                    case 1:
                        Console.WriteLine("Solicitou serviços...");
                        break;

                    case 0:
                        Environment.Exit(0); // Sair do programa
                        break;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Tente novamente.");
            }
        }
        #endregion

        #region Menu Candidato
        if (modo == 3)
        {

            Console.WriteLine("\n");
            Console.WriteLine("1. Candidatar-se");
            Console.WriteLine("0. Sair");
            Console.Write("Escolha uma opção: ");

            if (int.TryParse(Console.ReadLine(), out int opcao))
            {
                switch (opcao)
                {
                    case 1:
                        Console.WriteLine("Candidatou-se...");
                        break;

                    case 0:
                        Environment.Exit(0); // Sair do programa
                        break;

                    default:
                        Console.WriteLine("Opção inválida. Tente novamente.");
                        break;
                }
            }
            else
            {
                Console.WriteLine("Entrada inválida. Tente novamente.");
            }
        }
        #endregion
    }

    // =================================== FUNÇÕES ===================================

    #region gerir residente
    static void ListarResidentes()
    {
        Console.WriteLine("Lista de Residentes:");

        Console.WriteLine("-----------");
        foreach (Residente residente in listaResidentes)
        {
            residente.ListarResidentes();
            Console.WriteLine("-----------\n");
        }
    }

    static void AdicionarResidente()
    {
        Console.WriteLine("\nAdicionar Residente:");

        // Solicitar dados ao utilizador
        Console.Write("Nome: ");
        string nome = Console.ReadLine();
        
        Console.Write("Data Nascimento: \n");
        DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

        Console.Write("Morada: ");
        string morada = Console.ReadLine();
        
        Console.Write("Gênero: ");
        string genero = Console.ReadLine();
        
        Console.Write("Contacto: ");
        int contacto = int.Parse(Console.ReadLine());
        
        Console.Write("Utilizador: ");
        string utilizador = Console.ReadLine();
        
        Console.Write("Senha: ");
        string senha = Console.ReadLine();

        // Criar uma instância de Residente com os dados fornecidos pelo usuário
        Residente novoResidente = new Residente(nome, dataNasc, morada, genero, contacto, utilizador, senha, false, 0);

        // Adicionar à lista de residentes
        listaResidentes.Add(novoResidente);

        Console.WriteLine("Residente adicionado com sucesso!");
    }

    static void EditarResidente()
    {
        Console.WriteLine("Editar Residente:");

        // Solicitar ao usuário o nome do residente a ser editado
        Console.Write("Digite o nome do residente a ser editado: ");
        string nomeResidente = Console.ReadLine();

        // Procurar residente na lista pelo nome
        Residente residenteParaEditar = listaResidentes.Find(r => r.Utilizador.Equals(nomeResidente, StringComparison.OrdinalIgnoreCase));

        if (residenteParaEditar != null)
        {
            // Solicitar dados ao utilizador
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Data Nascimento: \n");
            DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            Console.Write("Morada: ");
            string morada = Console.ReadLine();

            Console.Write("Gênero: ");
            string genero = Console.ReadLine();

            Console.Write("Contacto: ");
            int contacto = int.Parse(Console.ReadLine());

            Console.Write("Utilizador: ");
            string utilizador = Console.ReadLine();

            Console.Write("Senha: ");
            string senha = Console.ReadLine();

            Console.Write("Estado: ");
            bool estado;
            int bool_detect = int.Parse(Console.ReadLine());
            if (bool_detect == 1)
            {
                estado = true;
            }
            else
            {
                estado = false;
            }

            Console.Write("Quarto: ");
            int quartoid = int.Parse(Console.ReadLine());

            residenteParaEditar.EditarDados(nome, dataNasc, morada, genero, contacto, senha, estado, quartoid);
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
    }

    static void RemoverResidente()
    {
        Console.WriteLine("Remover Residente:");

        // Solicitar ao usuário o nome do residente a ser removido
        Console.Write("Digite o nome do residente a ser removido: ");
        string nomeResidente = Console.ReadLine();

        // Procurar residente na lista pelo nome
        Residente residenteParaRemover = listaResidentes.Find(r => r.Utilizador.Equals(nomeResidente, StringComparison.OrdinalIgnoreCase));

        if (residenteParaRemover != null)
        {
            // Remover residente da lista
            listaResidentes.Remove(residenteParaRemover);

            Console.WriteLine("Residente removido com sucesso!");
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
    }
    #endregion
    #region gerir candidato
    static void ListarCandidatos()
    {
        Console.WriteLine("Lista de Residentes:");

        Console.WriteLine("-----------");
        foreach (Candidato candidato in listaCandidatos)
        {
            candidato.ListarCandidatos();
            Console.WriteLine("-----------\n");
        }
    }
    
    static void AdicionarCandidato()
    {
        Console.WriteLine("\nAdicionar Candidato:");

        // Solicitar dados ao utilizador
        Console.Write("Nome: ");
        string nome = Console.ReadLine();

        Console.Write("Data Nascimento: \n");
        DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

        Console.Write("Morada: ");
        string morada = Console.ReadLine();

        Console.Write("Gênero: ");
        string genero = Console.ReadLine();

        Console.Write("Contacto: ");
        int contacto = int.Parse(Console.ReadLine());

        Console.Write("Utilizador: ");
        string utilizador = Console.ReadLine();

        Console.Write("Senha: ");
        string senha = Console.ReadLine();

        // Criar uma instância de Residente com os dados fornecidos pelo usuário
        Candidato novoCandidato = new Candidato(nome, dataNasc, morada, genero, contacto, utilizador, senha, false);

        // Adicionar à lista de residentes
        listaCandidatos.Add(novoCandidato);

        Console.WriteLine("Candidato adicionado com sucesso!");
    }
    
    static void EditarCandidato()
    {
        Console.WriteLine("Editar Candidato:");

        // Solicitar ao usuário o nome do candidato a ser editado
        Console.Write("Digite o nome do candidato a ser editado: ");
        string nomeCandidato = Console.ReadLine();

        // Procurar candidato na lista pelo nome
        Candidato candidatoParaEditar = listaCandidatos.Find(r => r.Utilizador.Equals(nomeCandidato, StringComparison.OrdinalIgnoreCase));

        if (candidatoParaEditar != null)
        {
            // Solicitar dados ao utilizador
            Console.Write("Nome: ");
            string nome = Console.ReadLine();

            Console.Write("Data Nascimento: \n");
            DateOnly dataNasc = new DateOnly(int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()), int.Parse(Console.ReadLine()));

            Console.Write("Morada: ");
            string morada = Console.ReadLine();

            Console.Write("Gênero: ");
            string genero = Console.ReadLine();

            Console.Write("Contacto: ");
            int contacto = int.Parse(Console.ReadLine());

            Console.Write("Utilizador: ");
            string utilizador = Console.ReadLine();

            Console.Write("Senha: ");
            string senha = Console.ReadLine();

            Console.Write("Estado: ");
            bool estado;
            int bool_detect = int.Parse(Console.ReadLine());
            if (bool_detect == 1)
            {
                estado = true;
            }
            else
            {
                estado = false;
            }

            Console.Write("Quarto: ");
            int quartoid = int.Parse(Console.ReadLine());

            candidatoParaEditar.EditarDadosCandidatos(nome, dataNasc, morada, genero, contacto, senha, estado);
        }
        else
        {
            Console.WriteLine("Residente não encontrado!");
        }
    }
    
    static void RemoverCandidato()
    {
        Console.WriteLine("Remover Candidato:");

        // Solicitar ao usuário o nome do residente a ser removido
        Console.Write("Digite o nome do candidato a ser removido: ");
        string nomeCandidato = Console.ReadLine();

        // Procurar residente na lista pelo nome
        Candidato candidatoParaRemover = listaCandidatos.Find(r => r.Utilizador.Equals(nomeCandidato, StringComparison.OrdinalIgnoreCase));

        if (candidatoParaRemover != null)
        {
            // Remover residente da lista
            listaCandidatos.Remove(candidatoParaRemover);

            Console.WriteLine("Candidato removido com sucesso!");
        }
        else
        {
            Console.WriteLine("Candidato não encontrado!");
        }
    }
    #endregion
    #region gerir quarto
    static void ListarQuartos()
    {
        Console.WriteLine("Lista de Quartos:");

        Console.WriteLine("-----------");
        foreach (Alojamento quarto in listaQuartos)
        {
            quarto.ListarQuartos();
            Console.WriteLine("-----------\n");
        }
    }
    
    static void AdicionarQuarto()
    {
        Console.WriteLine("\nAdicionar Quarto:");

        // Solicitar dados ao utilizador
        Console.Write("Id: ");
        int id = int.Parse(Console.ReadLine());

        Console.Write("Tipo: ");
        string tipo = Console.ReadLine();

        // Criar uma instância de Residente com os dados fornecidos pelo usuário
        Alojamento novoQuarto = new Alojamento(id, tipo);

        // Adicionar à lista de residentes
        listaQuartos.Add(novoQuarto);

        Console.WriteLine("Quarto adicionado com sucesso!");
    }
    
    static void EditarQuarto()
    {
        Console.WriteLine("Editar Quarto:");

        // Solicitar ao usuário o nome do quarto a ser editado
        Console.Write("Digite o nome do quarto a ser editado: ");
        int id = int.Parse(Console.ReadLine());

        // Procurar quarto na lista pelo id
        Alojamento quartoParaEditar = listaQuartos.Find(r => r.Id.Equals(id));

        if (quartoParaEditar != null)
        {
            // Solicitar dados ao utilizador
            Console.Write("Tipo: ");
            string tipo = Console.ReadLine();

            quartoParaEditar.EditarDadosQuartos(id, tipo);
        }
        else
        {
            Console.WriteLine("Quarto não encontrado!");
        }
    }
    
    static void RemoverQuarto()
    {
        Console.WriteLine("Remover Quarto:");

        // Solicitar ao usuário o nome do quarto a ser removido
        Console.Write("Digite o nome do quarto a ser removido: ");
        int id = int.Parse(Console.ReadLine());

        // Procurar quarto na lista pelo nome
        Alojamento quartoParaRemover = listaQuartos.Find(r => r.Id.Equals(id));

        if (quartoParaRemover != null)
        {
            // Remover quarto da lista
            listaQuartos.Remove(quartoParaRemover);

            Console.WriteLine("Quarto removido com sucesso!");
        }
        else
        {
            Console.WriteLine("Candidato não encontrado!");
        }
    }
    #endregion
    #region gerir funcionario
    #endregion
}
